/* ============================================================
   MARKETER PRO — CONSTANTS
   ============================================================ */
import type { Platform } from '../types';

// ── PLATFORM METADATA ─────────────────────────────────────────
export const PLATFORM_CONFIG: Record<Platform, {
  label: string;
  color: string;
  charLimit: number;
  hashtagLimit: number;
  emoji: string;
}> = {
  instagram: { label: 'Instagram', color: '#E1306C', charLimit: 2200, hashtagLimit: 30, emoji: '📸' },
  facebook:  { label: 'Facebook',  color: '#1877F2', charLimit: 63206, hashtagLimit: 0, emoji: '👥' },
  twitter:   { label: 'X',         color: '#1DA1F2', charLimit: 280,   hashtagLimit: 2, emoji: '🐦' },
  linkedin:  { label: 'LinkedIn',  color: '#0A66C2', charLimit: 3000,  hashtagLimit: 5, emoji: '💼' },
  tiktok:    { label: 'TikTok',    color: '#010101', charLimit: 150,   hashtagLimit: 10, emoji: '🎬' },
  youtube:   { label: 'YouTube',   color: '#FF0000', charLimit: 5000,  hashtagLimit: 15, emoji: '▶️' },
  pinterest: { label: 'Pinterest', color: '#E60023', charLimit: 500,   hashtagLimit: 20, emoji: '📌' },
  snapchat:  { label: 'Snapchat',  color: '#FFFC00', charLimit: 250,   hashtagLimit: 0, emoji: '👻' },
};

// ── PLAN LIMITS ───────────────────────────────────────────────
export const PLAN_LIMITS = {
  free: {
    postsPerMonth: 3,
    platforms: 1,
    teamMembers: 1,
    socialAccounts: 1,
    analytics: 'basic' as const,
    autonomousMode: false,
  },
  pro: {
    postsPerMonth: 50,
    platforms: 3,
    teamMembers: 5,
    socialAccounts: 3,
    analytics: 'full' as const,
    autonomousMode: true,
  },
  enterprise: {
    postsPerMonth: Infinity,
    platforms: 8,
    teamMembers: Infinity,
    socialAccounts: Infinity,
    analytics: 'predictive' as const,
    autonomousMode: true,
  },
};

// ── PRICING ───────────────────────────────────────────────────
// IMPORTANT: Annual price must always display as total, not monthly breakdown
// Google Play Subscriptions Policy — explicit violation to show monthly as primary
export const PRICING = {
  pro: {
    monthly: { amount: 2900, display: '$29/month', stripeId: 'price_pro_monthly' },
    annual:  { amount: 34800, display: '$348/year', monthlyEquiv: '$29/mo', stripeId: 'price_pro_annual' },
  },
  enterprise: {
    monthly: { amount: 9900, display: '$99/month', stripeId: 'price_ent_monthly' },
    annual:  { amount: 118800, display: '$1,188/year', monthlyEquiv: '$99/mo', stripeId: 'price_ent_annual' },
  },
};

// ── DEMO ACCOUNT ──────────────────────────────────────────────
// Used during App Store review — never expose in UI
export const DEMO_ACCOUNT = {
  email: 'demo@marketer-pro.app',
  // Password stored in Railway env — never in code
};

// ── SUPPORT ───────────────────────────────────────────────────
export const SUPPORT = {
  email: 'support@marketer-pro.app',
  privacyEmail: 'privacy@marketer-pro.app',
  legalEmail: 'legal@marketer-pro.app',
  privacyUrl: 'https://marketer-pro.app/privacy',
  termsUrl: 'https://marketer-pro.app/terms',
  deleteAccountUrl: 'https://marketer-pro.app/delete-account',
  helpUrl: 'https://marketer-pro.app/help',
  supportEmail: 'support@marketer-pro.app',
};

// ── API ───────────────────────────────────────────────────────
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL as string;
export const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
export const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

// ── CONTENT GOALS ─────────────────────────────────────────────
export const CONTENT_GOAL_LABELS = {
  drive_traffic:       'Drive website traffic',
  generate_leads:      'Generate leads',
  build_awareness:     'Build brand awareness',
  announce_promotion:  'Announce a promotion',
  educate_audience:    'Educate my audience',
  build_community:     'Build community',
};

// ── HASHTAG STRATEGIES ────────────────────────────────────────
export const HASHTAG_STRATEGY_LABELS = {
  broad_reach:    'Broad reach (10-15 hashtags)',
  niche_focused:  'Niche focused (5-8 hashtags)',
  trending_only:  'Trending only',
  no_hashtags:    'No hashtags',
};

// ── INDUSTRY LABELS ───────────────────────────────────────────
export const INDUSTRY_LABELS = {
  tech_saas:              'Tech & SaaS',
  retail_ecommerce:       'Retail & E-commerce',
  health_wellness:        'Health & Wellness',
  creative_agency:        'Creative & Agency',
  food_beverage:          'Food & Beverage',
  professional_services:  'Professional Services',
  real_estate:            'Real Estate',
  education:              'Education',
  nonprofit:              'Nonprofit',
  other:                  'Other',
};
