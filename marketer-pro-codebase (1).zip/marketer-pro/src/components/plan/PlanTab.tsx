import { useState } from 'react'
import { CalendarGrid } from './CalendarGrid'
import { UpcomingPosts } from './UpcomingPosts'

export function PlanTab() {
  const [selectedDate, setSelectedDate] = useState<string | null>(null)

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 'var(--space-4) var(--space-5) var(--space-2)' }}>
        <h2>May 2026</h2>
        <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
          <button aria-label="Previous month" style={{ width: 32, height: 32, minHeight: 'var(--touch-target)', minWidth: 'var(--touch-target)', borderRadius: 'var(--radius-sm)', border: '0.5px solid var(--border)', background: 'var(--card)', cursor: 'pointer', color: 'var(--text-2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>‹</button>
          <button aria-label="Next month" style={{ width: 32, height: 32, minHeight: 'var(--touch-target)', minWidth: 'var(--touch-target)', borderRadius: 'var(--radius-sm)', border: '0.5px solid var(--border)', background: 'var(--card)', cursor: 'pointer', color: 'var(--text-2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>›</button>
        </div>
      </div>
      <CalendarGrid onSelectDate={setSelectedDate} selectedDate={selectedDate} />
      <div className="section-pad" style={{ paddingTop: 'var(--space-2)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-4)' }}>
          <h2>Upcoming Posts</h2>
          <button style={{ fontSize: 'var(--text-sm)', color: 'var(--brand)', fontWeight: 500, background: 'none', border: 'none', cursor: 'pointer', minHeight: 'var(--touch-target)', padding: 'var(--space-2)' }}>See all</button>
        </div>
        <UpcomingPosts />
      </div>
    </div>
  )
}
