const UPCOMING = [
  { time: '9:00 AM', platform: '📸', platformName: 'Instagram', title: 'Summer Sale — Instagram Post', detail: 'Today · 847 chars · 6 hashtags', status: 'live', statusLabel: 'Live', bg: '#fce4ec' },
  { time: '12:30 PM', platform: '💼', platformName: 'LinkedIn', title: 'Summer Sale — LinkedIn Post', detail: 'Today · 312 chars · Professional', status: 'pending', statusLabel: 'Pending', bg: '#e3f2fd' },
  { time: '3:00 PM', platform: '🐦', platformName: 'X / Twitter', title: 'Summer Sale — X Thread', detail: 'Tomorrow · 280 chars/tweet', status: 'scheduled', statusLabel: 'Scheduled', bg: '#e8f5e9' },
  { time: '6:00 PM', platform: '🎬', platformName: 'TikTok', title: 'Product Demo — TikTok Caption', detail: 'May 27 · 150 chars', status: 'draft', statusLabel: 'Draft', bg: '#f3e5f5' },
]

const STATUS_STYLES: Record<string, { bg: string; color: string }> = {
  live:      { bg: 'var(--accent-light)',  color: 'var(--accent-dark)' },
  pending:   { bg: 'var(--warn-light)',    color: '#92400E' },
  scheduled: { bg: 'var(--brand-light)',   color: 'var(--brand)' },
  draft:     { bg: 'var(--surface)',       color: 'var(--text-2)' },
}

export function UpcomingPosts() {
  return (
    <div className="card" style={{ padding: '4px 14px' }}>
      {UPCOMING.map((item, i) => (
        <div
          key={i}
          style={{
            display: 'flex', alignItems: 'flex-start', gap: 'var(--space-3)',
            padding: 'var(--space-3) 0',
            borderBottom: i < UPCOMING.length - 1 ? '0.5px solid var(--border)' : 'none',
          }}
        >
          <div style={{ fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--text-3)', width: 44, flexShrink: 0, paddingTop: 2 }}>{item.time}</div>
          <div
            style={{ width: 32, height: 32, borderRadius: 'var(--radius-sm)', background: item.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, flexShrink: 0 }}
            role="img"
            aria-label={item.platformName}
          >
            {item.platform}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 'var(--text-sm)', fontWeight: 600, color: 'var(--text-1)' }}>{item.title}</div>
            <div style={{ fontSize: 'var(--text-xs)', color: 'var(--text-3)', marginTop: 2 }}>{item.detail}</div>
          </div>
          <span
            className="pill"
            style={{
              background: STATUS_STYLES[item.status].bg,
              color: STATUS_STYLES[item.status].color,
              flexShrink: 0,
            }}
          >
            {item.statusLabel}
          </span>
        </div>
      ))}
    </div>
  )
}
