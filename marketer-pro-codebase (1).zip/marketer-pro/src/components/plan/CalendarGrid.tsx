interface Props {
  onSelectDate: (date: string) => void
  selectedDate: string | null
}

const DAYS = ['S', 'M', 'T', 'W', 'T', 'F', 'S']
const TODAY = 25
const POST_DAYS = [3, 7, 9, 12, 14, 18, 22, 24, 25, 26, 28]
const POST_DAYS_2 = [5, 11, 17, 21]

export function CalendarGrid({ onSelectDate, selectedDate }: Props) {
  return (
    <div style={{ padding: '0 var(--space-5)', marginBottom: 'var(--space-3)' }}>
      <div
        role="grid"
        aria-label="May 2026 calendar"
        style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2 }}
      >
        {/* Day labels */}
        {DAYS.map((d, i) => (
          <div key={i} role="columnheader" aria-label={['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][i]}
            style={{ textAlign: 'center', fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--text-3)', padding: '4px 0', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
            {d}
          </div>
        ))}
        {/* Day cells */}
        {Array.from({ length: 31 }, (_, i) => {
          const day = i + 1
          const isToday = day === TODAY
          const hasPost = POST_DAYS.includes(day)
          const hasPost2 = POST_DAYS_2.includes(day)
          return (
            <button
              key={day}
              role="gridcell"
              aria-label={`May ${day}, 2026${hasPost || hasPost2 ? ' — has scheduled posts' : ''}${isToday ? ' — today' : ''}`}
              onClick={() => onSelectDate(`2026-05-${String(day).padStart(2, '0')}`)}
              style={{
                aspectRatio: '1',
                borderRadius: 'var(--radius-sm)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                cursor: 'pointer', position: 'relative',
                background: isToday ? 'var(--brand)' : 'transparent',
                border: 'none',
                minHeight: 'var(--touch-target)',
                transition: 'background var(--duration-fast)',
              }}
            >
              <span style={{ fontSize: 'var(--text-sm)', fontWeight: isToday ? 700 : 500, color: isToday ? 'white' : 'var(--text-2)' }}>{day}</span>
              {(hasPost || hasPost2) && (
                <span style={{ width: 4, height: 4, borderRadius: '50%', background: hasPost ? 'var(--accent)' : 'var(--brand-mid)', position: 'absolute', bottom: 3 }} aria-hidden="true" />
              )}
            </button>
          )
        })}
      </div>
    </div>
  )
}
