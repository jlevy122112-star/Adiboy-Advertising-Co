import { useState } from 'react'
import { useAuth } from '../../hooks/useAuth'
import { supabase } from '../../api/supabase'
import { SUPPORT } from '../../constants'
import { ProfileHero } from './ProfileHero'
import { SettingsGroup } from './SettingsGroup'
import { DeleteAccountModal } from './DeleteAccountModal'

export function SettingsTab() {
  const { user } = useAuth()
  const [autonomousMode, setAutonomousMode] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [showAutonomousWarning, setShowAutonomousWarning] = useState(false)

  function handleAutonomousToggle() {
    if (!autonomousMode) {
      setShowAutonomousWarning(true)
    } else {
      setAutonomousMode(false)
    }
  }

  function confirmAutonomous() {
    setAutonomousMode(true)
    setShowAutonomousWarning(false)
  }

  async function handleSignOut() {
    await supabase.auth.signOut()
    window.location.reload()
  }

  return (
    <div>
      <ProfileHero user={user} />

      <div style={{ padding: 'var(--space-4) var(--space-5)' }}>
        <SettingsGroup
          label="Brand"
          items={[
            { icon: '🎨', label: 'Brand Profile', sub: 'Colors, voice, logo', chevron: true },
            { icon: '👥', label: 'Team Members', sub: '1 of 5 seats used', chevron: true },
            { icon: '🔗', label: 'Connected Platforms', sub: '3 of 8 connected', chevron: true },
          ]}
        />

        <SettingsGroup
          label="Account"
          items={[
            {
              icon: '💳',
              label: 'Billing & Plan',
              sub: `${user?.plan === 'pro' ? 'Pro · $29/mo' : 'Free Plan'}`,
              chevron: true,
            },
            {
              icon: '🤖',
              label: 'Autonomous Mode',
              sub: 'Auto-publish without review',
              toggle: true,
              toggleValue: autonomousMode,
              onToggle: handleAutonomousToggle,
            },
            { icon: '🔔', label: 'Notifications', sub: 'Push, email, in-app', chevron: true },
            { icon: '🔒', label: 'Privacy Policy', sub: SUPPORT.privacyUrl, chevron: true, href: SUPPORT.privacyUrl },
            { icon: '📄', label: 'Terms of Service', sub: SUPPORT.termsUrl, chevron: true, href: SUPPORT.termsUrl },
            { icon: '❓', label: 'Help & Support', chevron: true },
          ]}
        />

        <SettingsGroup
          label="Danger Zone"
          items={[
            {
              icon: '🗑️',
              label: 'Delete Account',
              sub: 'Permanently delete your account and all data',
              chevron: false,
              danger: true,
              onTap: () => setShowDeleteModal(true),
            },
          ]}
        />

        <button
          onClick={handleSignOut}
          style={{
            width: '100%',
            padding: 'var(--space-4)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius-md)',
            background: 'var(--card)',
            color: 'var(--text-2)',
            fontSize: 'var(--text-base)',
            cursor: 'pointer',
            minHeight: 'var(--touch-target)',
            marginBottom: 'var(--space-8)',
          }}
        >
          Sign Out
        </button>
      </div>

      {/* Autonomous Mode Warning — required by Apple + product spec */}
      {showAutonomousWarning && (
        <div
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="autonomous-warning-title"
          style={{
            position: 'absolute', inset: 0,
            background: 'rgba(26,16,51,0.8)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            padding: 'var(--space-5)',
            zIndex: 'var(--z-modal)',
          }}
        >
          <div style={{ background: 'var(--card)', borderRadius: 'var(--radius-xl)', padding: 'var(--space-6)', width: '100%' }}>
            <h3 id="autonomous-warning-title" style={{ fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--text-1)', marginBottom: 'var(--space-3)' }}>
              Enable Autonomous Mode?
            </h3>
            <p style={{ color: 'var(--text-2)', lineHeight: 1.6, marginBottom: 'var(--space-5)', fontSize: 'var(--text-sm)' }}>
              Autonomous Mode will publish content to your social accounts <strong>without per-post review</strong>.
              You remain responsible for all published content. Enable only if you have reviewed your brand settings carefully.
            </p>
            <button onClick={confirmAutonomous} style={{ width: '100%', background: 'var(--warn)', color: 'white', border: 'none', borderRadius: 'var(--radius-md)', padding: 'var(--space-4)', fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer', minHeight: 52, marginBottom: 'var(--space-2)' }}>
              I Understand — Enable
            </button>
            <button onClick={() => setShowAutonomousWarning(false)} style={{ width: '100%', background: 'transparent', border: 'none', color: 'var(--text-3)', cursor: 'pointer', padding: 'var(--space-3)', minHeight: 'var(--touch-target)' }}>
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Delete Account Modal — required by Apple 5.1.1(v) and Google Play */}
      {showDeleteModal && (
        <DeleteAccountModal
          onClose={() => setShowDeleteModal(false)}
          userId={user?.id}
        />
      )}
    </div>
  )
}
