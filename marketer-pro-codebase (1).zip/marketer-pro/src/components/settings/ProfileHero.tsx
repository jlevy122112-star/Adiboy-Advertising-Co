import type { User } from '../../types'

interface Props { user: User | null }

export function ProfileHero({ user }: Props) {
  const initials = user?.name
    ? user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
    : 'MP'

  const planLabel = user?.plan === 'pro' ? '✦ Pro Plan · 50 posts/mo'
    : user?.plan === 'enterprise' ? '✦ Enterprise Plan · Unlimited'
    : '✦ Free Plan · 3 posts/mo'

  return (
    <div style={{
      background: 'var(--brand)',
      borderRadius: 'var(--radius-xl)',
      margin: 'var(--space-4) var(--space-5) 0',
      padding: 'var(--space-5)',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
    }}>
      <div
        style={{
          width: 56, height: 56, borderRadius: 'var(--radius-md)',
          background: 'rgba(255,255,255,0.2)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'var(--text-2xl)',
          color: 'white', flexShrink: 0,
        }}
        aria-label={`Avatar for ${user?.name ?? 'user'}`}
      >
        {initials}
      </div>
      <div>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'var(--text-xl)', color: 'white' }}>
          {user?.name ?? 'Your Brand'}
        </div>
        <div style={{ fontSize: 'var(--text-xs)', color: 'rgba(255,255,255,0.7)', marginTop: 2 }}>
          {planLabel}
        </div>
      </div>
      <button
        style={{
          marginLeft: 'auto',
          background: 'rgba(255,255,255,0.15)',
          border: 'none',
          borderRadius: 'var(--radius-sm)',
          padding: '8px 12px',
          color: 'white',
          fontSize: 'var(--text-xs)',
          fontWeight: 600,
          cursor: 'pointer',
          minHeight: 'var(--touch-target)',
        }}
        aria-label="Edit profile"
      >
        Edit
      </button>
    </div>
  )
}
