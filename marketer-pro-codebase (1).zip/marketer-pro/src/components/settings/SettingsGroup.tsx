interface SettingsItem {
  icon: string
  label: string
  sub?: string
  chevron?: boolean
  toggle?: boolean
  toggleValue?: boolean
  onToggle?: () => void
  danger?: boolean
  onTap?: () => void
  href?: string
}

interface Props {
  label: string
  items: SettingsItem[]
}

export function SettingsGroup({ label, items }: Props) {
  return (
    <div style={{ marginBottom: 'var(--space-4)' }}>
      <div style={{ fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--text-3)', letterSpacing: '0.8px', textTransform: 'uppercase', marginBottom: 'var(--space-2)', paddingLeft: 4 }}>
        {label}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {items.map(item => (
          <div
            key={item.label}
            role={item.onTap || item.href ? 'button' : undefined}
            tabIndex={item.onTap || item.href ? 0 : undefined}
            onClick={item.onTap}
            aria-label={item.label + (item.sub ? ` — ${item.sub}` : '')}
            style={{
              display: 'flex', alignItems: 'center', gap: 'var(--space-3)',
              padding: '13px 14px',
              background: 'var(--card)',
              borderRadius: 'var(--radius-md)',
              border: '0.5px solid var(--border)',
              cursor: item.onTap || item.toggle ? 'pointer' : 'default',
              transition: 'background var(--duration-fast)',
              minHeight: 'var(--touch-target)',
              ...(item.danger ? { borderColor: 'var(--danger-light)' } : {}),
            }}
          >
            <span style={{ fontSize: 20, width: 24, color: item.danger ? 'var(--danger)' : 'var(--brand)', flexShrink: 0 }} aria-hidden="true">
              {item.icon}
            </span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 'var(--text-base)', color: item.danger ? 'var(--danger)' : 'var(--text-1)', fontWeight: 500 }}>{item.label}</div>
              {item.sub && <div style={{ fontSize: 'var(--text-xs)', color: 'var(--text-3)', marginTop: 1 }}>{item.sub}</div>}
            </div>
            {item.toggle && (
              <div
                role="switch"
                aria-checked={item.toggleValue}
                aria-label={`${item.label} toggle`}
                onClick={item.onToggle}
                style={{
                  width: 42, height: 24,
                  background: item.toggleValue ? 'var(--accent)' : 'var(--surface)',
                  borderRadius: 'var(--radius-full)',
                  position: 'relative', cursor: 'pointer',
                  border: '1px solid var(--border)',
                  transition: 'background var(--duration-base)',
                }}
              >
                <div style={{
                  width: 20, height: 20, borderRadius: '50%',
                  background: 'white',
                  position: 'absolute', top: 1,
                  left: item.toggleValue ? 20 : 2,
                  transition: 'left var(--duration-base)',
                  boxShadow: '0 1px 4px rgba(0,0,0,0.15)',
                }} />
              </div>
            )}
            {item.chevron && (
              <span style={{ color: 'var(--text-3)', fontSize: 16 }} aria-hidden="true">›</span>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
