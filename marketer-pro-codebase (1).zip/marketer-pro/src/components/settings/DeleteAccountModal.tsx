/**
 * DELETE ACCOUNT MODAL
 * Required by:
 * - Apple Guideline 5.1.1(v) — hard requirement, in-app account deletion
 * - Google Play Account Deletion Requirement
 * - Must actually delete all user data server-side
 * - Must be accessible from Settings without contacting support
 */
import { useState } from 'react'
import { supabase } from '../../api/supabase'
import { api } from '../../api/client'
import { SUPPORT } from '../../constants'

interface Props {
  onClose: () => void
  userId: string | undefined
}

export function DeleteAccountModal({ onClose, userId }: Props) {
  const [step, setStep] = useState<'confirm' | 'deleting' | 'done'>('confirm')
  const [error, setError] = useState<string | null>(null)

  async function handleDelete() {
    if (!userId) return
    setStep('deleting')

    const result = await api.delete('/api/v1/account')
    if (result.success) {
      await supabase.auth.signOut()
      setStep('done')
    } else {
      setError('Deletion failed. Please try again or contact ' + SUPPORT.supportEmail)
      setStep('confirm')
    }
  }

  return (
    <div
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="delete-title"
      style={{
        position: 'absolute', inset: 0,
        background: 'rgba(26,16,51,0.85)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 'var(--space-5)',
        zIndex: 'var(--z-modal)',
      }}
    >
      <div style={{ background: 'var(--card)', borderRadius: 'var(--radius-xl)', padding: 'var(--space-6)', width: '100%' }}>
        {step === 'confirm' && (
          <>
            <div style={{ textAlign: 'center', marginBottom: 'var(--space-4)' }}>
              <div style={{ fontSize: 48 }} aria-hidden="true">⚠️</div>
            </div>
            <h3 id="delete-title" style={{ fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--text-1)', marginBottom: 'var(--space-3)', textAlign: 'center' }}>
              Delete Account?
            </h3>
            <p style={{ color: 'var(--text-2)', lineHeight: 1.6, marginBottom: 'var(--space-3)', fontSize: 'var(--text-sm)', textAlign: 'center' }}>
              This will permanently delete your account and <strong>all associated data</strong> including your brand profile, generated posts, connected platforms, and billing history.
            </p>
            <p style={{ color: 'var(--text-3)', fontSize: 'var(--text-xs)', textAlign: 'center', marginBottom: 'var(--space-5)' }}>
              This action cannot be undone. Deletion is processed within 24 hours.
            </p>
            {error && (
              <p role="alert" style={{ color: 'var(--danger)', fontSize: 'var(--text-sm)', marginBottom: 'var(--space-3)', userSelect: 'text' }}>
                {error}
              </p>
            )}
            <button
              onClick={handleDelete}
              style={{ width: '100%', background: 'var(--danger)', color: 'white', border: 'none', borderRadius: 'var(--radius-md)', padding: 'var(--space-4)', fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer', minHeight: 52, marginBottom: 'var(--space-2)' }}
            >
              Yes, Delete My Account
            </button>
            <button
              onClick={onClose}
              style={{ width: '100%', background: 'transparent', border: 'none', color: 'var(--text-3)', cursor: 'pointer', padding: 'var(--space-3)', minHeight: 'var(--touch-target)' }}
              autoFocus
            >
              Cancel — Keep My Account
            </button>
          </>
        )}
        {step === 'deleting' && (
          <div style={{ textAlign: 'center', padding: 'var(--space-8) 0' }}>
            <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-2)' }} role="status" aria-live="polite">
              Deleting your account...
            </div>
          </div>
        )}
        {step === 'done' && (
          <div style={{ textAlign: 'center', padding: 'var(--space-6) 0' }}>
            <div style={{ fontSize: 48, marginBottom: 'var(--space-3)' }} aria-hidden="true">✓</div>
            <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--text-1)' }}>Account Deleted</h3>
            <p style={{ color: 'var(--text-2)', marginTop: 'var(--space-2)', fontSize: 'var(--text-sm)' }}>
              Your data will be fully removed within 24 hours. A confirmation email has been sent.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
