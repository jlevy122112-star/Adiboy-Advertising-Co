/* ============================================================
   MARKETER PRO — CARD COMPONENT
   ============================================================ */
import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  role?: string;
  ariaLabel?: string;
}

export function Card({ children, className = '', onClick, role, ariaLabel }: CardProps) {
  return (
    <div
      className={['card', onClick ? 'cursor-pointer hover:shadow-[var(--shadow-md)] transition-shadow' : '', className].join(' ')}
      onClick={onClick}
      role={role}
      aria-label={ariaLabel}
    >
      {children}
    </div>
  );
}
