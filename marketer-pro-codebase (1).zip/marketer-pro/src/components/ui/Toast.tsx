/* ============================================================
   MARKETER PRO — TOAST COMPONENT
   aria-live="polite" for success, "assertive" for errors
   ============================================================ */
import React, { useEffect } from 'react';

type ToastType = 'success' | 'error' | 'info';

interface ToastProps {
  message: string;
  type?: ToastType;
  duration?: number;
  onDismiss: () => void;
}

const typeStyles: Record<ToastType, string> = {
  success: 'bg-[var(--accent)] text-white',
  error:   'bg-[var(--danger)] text-white',
  info:    'bg-[var(--brand)] text-white',
};

export function Toast({ message, type = 'success', duration = 3000, onDismiss }: ToastProps) {
  useEffect(() => {
    const timer = setTimeout(onDismiss, duration);
    return () => clearTimeout(timer);
  }, [duration, onDismiss]);

  return (
    <div
      role="alert"
      aria-live={type === 'error' ? 'assertive' : 'polite'}
      className={[
        'fixed top-4 left-4 right-4 z-[var(--z-toast)]',
        'flex items-center gap-3',
        'px-4 py-3 rounded-[var(--radius-md)]',
        'shadow-[var(--shadow-lg)]',
        'animate-fade-up',
        typeStyles[type],
      ].join(' ')}
    >
      <span className="flex-1 text-[var(--text-base)] font-500">{message}</span>
      <button
        onClick={onDismiss}
        aria-label="Dismiss notification"
        className="opacity-75 hover:opacity-100 transition-opacity min-h-[var(--touch-target)] min-w-[var(--touch-target)] flex items-center justify-center"
      >
        ✕
      </button>
    </div>
  );
}
