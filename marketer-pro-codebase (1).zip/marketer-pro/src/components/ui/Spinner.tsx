/* ============================================================
   MARKETER PRO — SPINNER COMPONENT
   Always includes aria-label for accessibility
   ============================================================ */
interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  label?: string;
}

const sizes = { sm: 'w-4 h-4', md: 'w-8 h-8', lg: 'w-12 h-12' };

export function Spinner({ size = 'md', label = 'Loading...' }: SpinnerProps) {
  return (
    <div
      role="status"
      aria-label={label}
      className={[
        sizes[size],
        'border-3 border-[var(--brand-light)] border-t-[var(--brand)]',
        'rounded-full animate-spin',
      ].join(' ')}
    />
  );
}
