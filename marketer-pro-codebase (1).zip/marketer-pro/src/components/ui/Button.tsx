/* ============================================================
   MARKETER PRO — BUTTON COMPONENT
   48px minimum touch target (Google + Apple requirement)
   Full ARIA support
   ============================================================ */
import React from 'react';

type ButtonVariant = 'primary' | 'secondary' | 'accent' | 'ghost' | 'danger';
type ButtonSize = 'sm' | 'md' | 'lg';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  fullWidth?: boolean;
  icon?: React.ReactNode;
  children: React.ReactNode;
}

const variantStyles: Record<ButtonVariant, string> = {
  primary:   'bg-[var(--brand)] text-white hover:bg-[var(--brand-dark)]',
  secondary: 'bg-[var(--brand-light)] text-[var(--brand)] hover:bg-[var(--brand-mid)] hover:text-white',
  accent:    'bg-[var(--accent)] text-white hover:bg-[var(--accent-dark)]',
  ghost:     'bg-transparent text-[var(--brand)] border border-[var(--border)] hover:bg-[var(--brand-light)]',
  danger:    'bg-[var(--danger)] text-white hover:opacity-90',
};

const sizeStyles: Record<ButtonSize, string> = {
  sm: 'px-3 py-2 text-[var(--text-sm)] min-h-[var(--touch-target)]',
  md: 'px-4 py-3 text-[var(--text-base)] min-h-[var(--touch-target)]',
  lg: 'px-6 py-4 text-[var(--text-md)] min-h-[52px]',
};

export function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  fullWidth = false,
  icon,
  children,
  disabled,
  className = '',
  ...props
}: ButtonProps) {
  const isDisabled = disabled || loading;

  return (
    <button
      disabled={isDisabled}
      aria-busy={loading}
      className={[
        'inline-flex items-center justify-center gap-2',
        'font-[var(--font-display)] font-700',
        'rounded-[var(--radius-md)]',
        'transition-all duration-[var(--duration-fast)]',
        'active:scale-[0.98]',
        variantStyles[variant],
        sizeStyles[size],
        fullWidth ? 'w-full' : '',
        isDisabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',
        className,
      ].join(' ')}
      {...props}
    >
      {loading ? (
        <span
          className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"
          aria-hidden="true"
        />
      ) : icon ? (
        <span aria-hidden="true">{icon}</span>
      ) : null}
      {children}
    </button>
  );
}
