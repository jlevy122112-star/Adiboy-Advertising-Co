const KPIS = [
  { label: 'Total Reach',     value: '48.2K', change: '+22%', up: true,  ariaLabel: 'Total Reach: 48.2 thousand. Up 22% compared to last week.' },
  { label: 'Engagement',      value: '6.4%',  change: '+8%',  up: true,  ariaLabel: 'Engagement rate: 6.4 percent. Up 8% compared to last week.' },
  { label: 'Posts Published', value: '12',    change: 'On track', up: true, ariaLabel: 'Posts published: 12. On track.' },
  { label: 'Link Clicks',     value: '1.8K',  change: '-4%',  up: false, ariaLabel: 'Link Clicks: 1.8 thousand. Down 4% compared to last week.' },
]

export function KPICards() {
  return (
    <div
      style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-3)', marginBottom: 'var(--space-4)' }}
      role="region"
      aria-label="Performance metrics"
    >
      {KPIS.map(kpi => (
        <div
          key={kpi.label}
          className="card"
          aria-label={kpi.ariaLabel}
        >
          <div style={{ fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--text-3)', letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: 4 }}>{kpi.label}</div>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'var(--text-4xl)', color: 'var(--text-1)', lineHeight: 1 }}>{kpi.value}</div>
          <div style={{ fontSize: 'var(--text-xs)', marginTop: 4, fontWeight: 600, color: kpi.up ? 'var(--accent)' : 'var(--danger)' }}>
            {kpi.up ? '↑' : '↓'} {kpi.change}
          </div>
        </div>
      ))}
    </div>
  )
}
