const INSIGHTS = [
  {
    icon: '✨',
    text: 'Your Instagram posts are outperforming your average by 40%. Posting between 8–10 AM is your sweet spot.',
    action: '+ Generate more Instagram content',
    ariaLabel: 'AI Insight: Your Instagram posts outperform your average by 40 percent. Posting between 8 and 10 AM is your sweet spot. Recommended action: Generate more Instagram content.',
  },
  {
    icon: '📈',
    text: 'Link clicks are down 4% — try adding a stronger CTA to your next LinkedIn post.',
    action: '→ Generate LinkedIn post now',
    ariaLabel: 'AI Insight: Link clicks are down 4 percent. Try adding a stronger call to action to your next LinkedIn post. Recommended action: Generate LinkedIn post now.',
  },
]

export function AIInsights() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
      {INSIGHTS.map((insight, i) => (
        <div
          key={i}
          style={{
            background: 'var(--brand-light)',
            borderRadius: 'var(--radius-md)',
            padding: 'var(--space-4)',
            display: 'flex',
            gap: 'var(--space-3)',
            alignItems: 'flex-start',
          }}
          aria-label={insight.ariaLabel}
        >
          <span style={{ fontSize: 20, flexShrink: 0 }} aria-hidden="true">{insight.icon}</span>
          <div>
            <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-1)', lineHeight: 1.5 }}>{insight.text}</p>
            <button
              style={{
                marginTop: 'var(--space-2)',
                fontSize: 'var(--text-xs)',
                fontWeight: 700,
                color: 'var(--brand)',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: 0,
                minHeight: 'var(--touch-target)',
                display: 'inline-flex',
                alignItems: 'center',
              }}
            >
              {insight.action}
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}
