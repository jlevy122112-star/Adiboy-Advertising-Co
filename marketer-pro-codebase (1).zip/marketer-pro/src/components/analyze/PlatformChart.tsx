const BARS = [
  { platform: 'Instagram', pct: 92, color: '#E1306C' },
  { platform: 'LinkedIn',  pct: 74, color: '#0A66C2' },
  { platform: 'Facebook',  pct: 61, color: '#1877F2' },
  { platform: 'X / Twitter', pct: 48, color: '#1DA1F2' },
  { platform: 'TikTok',    pct: 38, color: '#010101' },
  { platform: 'YouTube',   pct: 22, color: '#FF0000' },
]

export function PlatformChart() {
  return (
    <div
      className="card"
      role="img"
      aria-label="Platform performance bar chart. Instagram leads at 92 percent, followed by LinkedIn at 74 percent, Facebook at 61 percent, X Twitter at 48 percent, TikTok at 38 percent, and YouTube at 22 percent."
    >
      {/* Hide individual tick labels from screen readers — covered by aria-label above */}
      <div aria-hidden="true">
        {BARS.map(bar => (
          <div key={bar.platform} style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)', marginBottom: 'var(--space-3)' }}>
            <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-2)', width: 80, flexShrink: 0, fontWeight: 500 }}>{bar.platform}</div>
            <div style={{ flex: 1, background: 'var(--surface)', borderRadius: 'var(--radius-full)', height: 8, overflow: 'hidden' }}>
              <div
                style={{
                  height: '100%',
                  width: `${bar.pct}%`,
                  background: bar.color,
                  borderRadius: 'var(--radius-full)',
                  transition: 'width 0.6s var(--ease-spring)',
                }}
              />
            </div>
            <div style={{ fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--text-2)', width: 32, textAlign: 'right' }}>{bar.pct}%</div>
          </div>
        ))}
      </div>
    </div>
  )
}
