import { KPICards } from './KPICards'
import { PlatformChart } from './PlatformChart'
import { AIInsights } from './AIInsights'

export function AnalyzeTab() {
  return (
    <div className="section-pad">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-4)' }}>
        <h2>Performance</h2>
        <span className="pill pill--brand">Last 7 days</span>
      </div>
      <KPICards />
      <h2 style={{ margin: 'var(--space-4) 0 var(--space-3)' }}>Platform Breakdown</h2>
      <PlatformChart />
      <h2 style={{ margin: 'var(--space-4) 0 var(--space-3)' }}>AI Insights</h2>
      <AIInsights />
    </div>
  )
}
