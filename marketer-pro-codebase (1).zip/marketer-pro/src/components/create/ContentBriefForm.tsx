import { CONTENT_GOAL_LABELS, HASHTAG_STRATEGY_LABELS } from '../../constants'
import type { ContentBrief, ContentGoal, HashtagStrategy, PostUrgency } from '../../types'

interface Props {
  value: Partial<ContentBrief>
  onChange: (u: Partial<ContentBrief>) => void
  onGenerate: () => void
  error: string | null
}

const labelStyle = {
  display: 'block',
  fontSize: 'var(--text-xs)',
  fontWeight: 700,
  color: 'var(--text-2)',
  textTransform: 'uppercase' as const,
  letterSpacing: '0.5px',
  marginBottom: 6,
}

export function ContentBriefForm({ value, onChange, onGenerate, error }: Props) {
  return (
    <div>
      <h3 style={{ marginBottom: 'var(--space-4)', color: 'var(--text-1)' }}>Content brief</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
        <div>
          <label htmlFor="topic" style={labelStyle}>Topic / Tagline *</label>
          <input
            id="topic"
            type="text"
            placeholder="e.g. Summer sale — 30% off all plans"
            value={value.topic ?? ''}
            onChange={e => onChange({ topic: e.target.value })}
            aria-required="true"
          />
        </div>

        <div>
          <label htmlFor="goal" style={labelStyle}>Content Goal</label>
          <select id="goal" value={value.goal ?? 'build_awareness'} onChange={e => onChange({ goal: e.target.value as ContentGoal })}>
            {(Object.entries(CONTENT_GOAL_LABELS) as [ContentGoal, string][]).map(([v, l]) => (
              <option key={v} value={v}>{l}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="cta" style={labelStyle}>Call to Action</label>
          <input id="cta" type="text" placeholder="e.g. Visit our website, DM us, Book now" value={value.callToAction ?? ''} onChange={e => onChange({ callToAction: e.target.value })} />
        </div>

        <div>
          <label htmlFor="hashtags" style={labelStyle}>Hashtag Strategy</label>
          <select id="hashtags" value={value.hashtagStrategy ?? 'broad_reach'} onChange={e => onChange({ hashtagStrategy: e.target.value as HashtagStrategy })}>
            {(Object.entries(HASHTAG_STRATEGY_LABELS) as [HashtagStrategy, string][]).map(([v, l]) => (
              <option key={v} value={v}>{l}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="urgency" style={labelStyle}>Post Urgency</label>
          <select id="urgency" value={value.urgency ?? 'normal'} onChange={e => onChange({ urgency: e.target.value as PostUrgency })}>
            <option value="normal">Normal</option>
            <option value="urgent">Urgent — time sensitive!</option>
            <option value="soft_sell">Low key / soft sell</option>
          </select>
        </div>

        {error && (
          <p
            role="alert"
            aria-live="assertive"
            style={{
              color: 'var(--danger)',
              fontSize: 'var(--text-sm)',
              padding: 'var(--space-3)',
              background: 'var(--danger-light)',
              borderRadius: 'var(--radius-sm)',
              userSelect: 'text', // Selectable for support requests
            }}
          >
            {error}
          </p>
        )}

        <button
          onClick={onGenerate}
          disabled={!value.topic?.trim()}
          style={{
            width: '100%',
            background: 'var(--brand)',
            color: 'white',
            border: 'none',
            borderRadius: 'var(--radius-md)',
            padding: 'var(--space-4)',
            fontFamily: 'var(--font-display)',
            fontWeight: 700,
            fontSize: 'var(--text-md)',
            cursor: value.topic?.trim() ? 'pointer' : 'not-allowed',
            opacity: value.topic?.trim() ? 1 : 0.5,
            minHeight: 56,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 'var(--space-2)',
            transition: 'all var(--duration-fast)',
          }}
          aria-label="Generate posts for selected platforms"
        >
          ✨ Generate Posts
        </button>
      </div>
    </div>
  )
}
