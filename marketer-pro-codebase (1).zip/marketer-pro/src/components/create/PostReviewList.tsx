import { PLATFORM_CONFIG } from '../../constants'
import type { GeneratedPost, Platform } from '../../types'

interface Props {
  posts: GeneratedPost[]
  onApprove: (id: string) => void
  onReject: (id: string) => void
  onReport: (id: string) => void
}

export function PostReviewList({ posts, onApprove, onReject, onReport }: Props) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
      {posts.map(post => (
        <PostCard
          key={post.id}
          post={post}
          onApprove={() => onApprove(post.id)}
          onReject={() => onReject(post.id)}
          onReport={() => onReport(post.id)}
        />
      ))}
    </div>
  )
}

function PostCard({ post, onApprove, onReject, onReport }: {
  post: GeneratedPost
  onApprove: () => void
  onReject: () => void
  onReport: () => void
}) {
  const config = PLATFORM_CONFIG[post.platform as Platform]
  const isApproved = post.status === 'approved'
  const isReported = !!post.reportedAt

  return (
    <article
      style={{
        background: 'var(--card)',
        borderRadius: 'var(--radius-md)',
        border: `0.5px solid ${isApproved ? 'var(--accent)' : 'var(--border)'}`,
        overflow: 'hidden',
        transition: 'border-color var(--duration-fast)',
      }}
      aria-label={`${config.label} post — ${isApproved ? 'approved' : 'pending review'}`}
    >
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 'var(--space-3)',
        padding: 'var(--space-3) var(--space-4)',
        borderBottom: '0.5px solid var(--border)',
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: 'var(--radius-sm)',
          background: `${config.color}20`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 14,
        }} aria-hidden="true">
          {config.emoji}
        </div>
        <span style={{ fontWeight: 600, color: 'var(--text-1)', fontSize: 'var(--text-sm)' }}>
          {config.label}
        </span>
        <span style={{ marginLeft: 'auto', fontSize: 'var(--text-xs)', color: 'var(--text-3)' }}
          aria-label={`${post.charCount} of ${config.charLimit} characters`}>
          {post.charCount} / {config.charLimit}
        </span>
      </div>

      {/* Content */}
      <div style={{ padding: 'var(--space-3) var(--space-4)', fontSize: 'var(--text-sm)', color: 'var(--text-1)', lineHeight: 1.6 }}>
        {post.content}
        {post.hashtags.length > 0 && (
          <div style={{ color: 'var(--brand)', marginTop: 8, fontSize: 'var(--text-xs)' }}>
            {post.hashtags.map(h => `#${h}`).join(' ')}
          </div>
        )}
      </div>

      {/* Actions */}
      {isApproved ? (
        <div style={{
          padding: 'var(--space-3) var(--space-4)',
          background: 'var(--accent-light)',
          display: 'flex', alignItems: 'center', gap: 'var(--space-2)',
          fontSize: 'var(--text-sm)', fontWeight: 600, color: 'var(--accent-dark)',
        }}>
          <span aria-hidden="true">✓</span>
          Approved — ready to schedule
        </div>
      ) : isReported ? (
        <div style={{
          padding: 'var(--space-3) var(--space-4)',
          background: 'var(--danger-light)',
          fontSize: 'var(--text-sm)', color: 'var(--danger)',
        }}>
          Reported — thank you for your feedback
        </div>
      ) : (
        <div style={{
          display: 'flex', gap: 'var(--space-2)',
          padding: 'var(--space-2) var(--space-3)',
          background: 'var(--surface)',
        }}>
          <button
            onClick={onApprove}
            aria-label={`Approve ${config.label} post`}
            style={{
              flex: 1, padding: 'var(--space-2)', borderRadius: 'var(--radius-sm)',
              border: '1px solid var(--accent-light)', background: 'var(--accent-light)',
              color: 'var(--accent-dark)', fontSize: 'var(--text-xs)', fontWeight: 600,
              cursor: 'pointer', minHeight: 'var(--touch-target)',
            }}
          >
            ✓ Approve
          </button>
          <button
            onClick={onReject}
            aria-label={`Regenerate ${config.label} post`}
            style={{
              flex: 1, padding: 'var(--space-2)', borderRadius: 'var(--radius-sm)',
              border: '1px solid var(--brand-light)', background: 'white',
              color: 'var(--brand)', fontSize: 'var(--text-xs)', fontWeight: 600,
              cursor: 'pointer', minHeight: 'var(--touch-target)',
            }}
          >
            ↺ Redo
          </button>
          {/* Report button — required by Apple 1.2 and Google AI Content Policy */}
          <button
            onClick={onReport}
            aria-label={`Report ${config.label} post as offensive`}
            title="Report offensive content"
            style={{
              padding: 'var(--space-2) var(--space-3)', borderRadius: 'var(--radius-sm)',
              border: '1px solid var(--danger-light)', background: 'white',
              color: 'var(--danger)', fontSize: 'var(--text-xs)', fontWeight: 600,
              cursor: 'pointer', minHeight: 'var(--touch-target)',
            }}
          >
            🚩
          </button>
        </div>
      )}
    </article>
  )
}
