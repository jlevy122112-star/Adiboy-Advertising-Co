interface Props { onGetStarted: () => void }

export function HeroBanner({ onGetStarted }: Props) {
  return (
    <div style={{ padding: 'var(--space-4) var(--space-5) 0' }}>
      <div style={{
        background: 'var(--brand)', borderRadius: 'var(--radius-xl)',
        padding: 'var(--space-5) var(--space-5) 0', overflow: 'hidden', position: 'relative',
      }}>
        <div style={{ position: 'absolute', width: 180, height: 180, borderRadius: '50%', background: 'rgba(255,255,255,0.06)', top: -60, right: -40 }} aria-hidden="true" />
        <p style={{ fontSize: 'var(--text-xs)', fontWeight: 700, color: 'rgba(255,255,255,0.7)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 'var(--space-2)', position: 'relative' }}>AI Studio</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'var(--text-4xl)', color: 'white', lineHeight: 1.2, marginBottom: 'var(--space-2)', position: 'relative' }}>
          What will you<br />create today?
        </h1>
        <p style={{ color: 'rgba(255,255,255,0.75)', marginBottom: 'var(--space-5)', fontSize: 'var(--text-base)', position: 'relative' }}>
          Your brand voice, 8 platforms, one tap.
        </p>
        <button
          onClick={onGetStarted}
          style={{
            background: 'white', color: 'var(--brand)', border: 'none',
            borderRadius: 'var(--radius-md) var(--radius-md) 0 0',
            padding: 'var(--space-4) var(--space-5)',
            fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'var(--text-md)',
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 'var(--space-2)',
            width: '100%', minHeight: 52, position: 'relative',
            transition: 'background var(--duration-fast)',
          }}
          aria-label="Generate your first post — open content creation form"
        >
          <span aria-hidden="true">✨</span>
          Generate your first post
          <span style={{ marginLeft: 'auto' }} aria-hidden="true">→</span>
        </button>
      </div>
    </div>
  )
}
