import { PLATFORM_CONFIG } from '../../constants'
import type { Platform } from '../../types'

interface Props {
  selected: Platform[]
  onChange: (platforms: Platform[]) => void
}

export function PlatformPicker({ selected, onChange }: Props) {
  function toggle(platform: Platform) {
    if (selected.includes(platform)) {
      if (selected.length > 1) onChange(selected.filter(p => p !== platform))
    } else {
      onChange([...selected, platform])
    }
  }

  return (
    <div>
      <h3 style={{ marginBottom: 'var(--space-3)', color: 'var(--text-1)' }}>Choose platforms</h3>
      <div
        role="group"
        aria-label="Select social media platforms"
        style={{ display: 'flex', flexWrap: 'wrap', gap: 'var(--space-2)' }}
      >
        {(Object.entries(PLATFORM_CONFIG) as [Platform, typeof PLATFORM_CONFIG[Platform]][]).map(([id, config]) => {
          const isSelected = selected.includes(id)
          return (
            <button
              key={id}
              role="checkbox"
              aria-checked={isSelected}
              aria-label={`${config.label} — ${isSelected ? 'selected' : 'not selected'}`}
              onClick={() => toggle(id)}
              style={{
                display: 'flex', alignItems: 'center', gap: 'var(--space-2)',
                padding: '8px 12px',
                borderRadius: 'var(--radius-md)',
                border: `1.5px solid ${isSelected ? 'var(--brand)' : 'var(--border)'}`,
                background: isSelected ? 'var(--brand-light)' : 'var(--card)',
                color: isSelected ? 'var(--brand)' : 'var(--text-2)',
                fontSize: 'var(--text-sm)', fontWeight: 600, cursor: 'pointer',
                minHeight: 'var(--touch-target)',
                transition: 'all var(--duration-fast)',
              }}
            >
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: config.color, flexShrink: 0 }} aria-hidden="true" />
              {config.label}
            </button>
          )
        })}
      </div>
    </div>
  )
}
