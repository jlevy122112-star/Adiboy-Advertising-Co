import { useState } from 'react'
import { useAuth } from '../../hooks/useAuth'
import { useBrandProfile, buildBrandContextForAI } from '../../hooks/useBrandProfile'
import { useFeatureFlags } from '../../hooks/useFeatureFlags'
import { api } from '../../api/client'
import { HeroBanner } from './HeroBanner'
import { PlatformPicker } from './PlatformPicker'
import { ContentBriefForm } from './ContentBriefForm'
import { PostReviewList } from './PostReviewList'
import { ScheduleSheet } from './ScheduleSheet'
import { Spinner } from '../ui/Spinner'
import type { Platform, ContentBrief, GeneratedPost } from '../../types'

type CreateState = 'hero' | 'brief' | 'generating' | 'review' | 'scheduled'

export function CreateTab() {
  const { user } = useAuth()
  const { profile } = useBrandProfile(user?.id)
  const { flags } = useFeatureFlags()
  const [state, setState] = useState<CreateState>('hero')
  const [selectedPlatforms, setSelectedPlatforms] = useState<Platform[]>(['instagram'])
  const [brief, setBrief] = useState<Partial<ContentBrief>>({
    goal: 'build_awareness',
    hashtagStrategy: 'broad_reach',
    urgency: 'normal',
  })
  const [posts, setPosts] = useState<GeneratedPost[]>([])
  const [showSchedule, setShowSchedule] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleGenerate() {
    if (!profile || !flags.ai_generation) return
    setState('generating')
    setError(null)

    const fullBrief: ContentBrief = {
      platforms: selectedPlatforms,
      topic: brief.topic ?? '',
      goal: brief.goal ?? 'build_awareness',
      callToAction: brief.callToAction ?? 'Learn more',
      hashtagStrategy: brief.hashtagStrategy ?? 'broad_reach',
      urgency: brief.urgency ?? 'normal',
    }

    const brandContext = buildBrandContextForAI(profile)
    const result = await api.post<GeneratedPost[]>('/api/v1/generate', {
      brief: fullBrief,
      brandContext,
    })

    if (result.success && result.data) {
      setPosts(result.data)
      setState('review')
    } else {
      setError(result.error ?? 'Generation failed. Please try again.')
      setState('brief')
    }
  }

  function handleApprove(postId: string) {
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, status: 'approved' } : p))
  }

  function handleReject(postId: string) {
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, status: 'rejected' } : p))
  }

  // Report offensive AI content — required by Apple 1.2 and Google AI Content Policy
  function handleReport(postId: string) {
    api.post('/api/v1/posts/report', { postId, reason: 'offensive' })
    setPosts(prev => prev.map(p => p.id === postId
      ? { ...p, reportedAt: new Date().toISOString(), status: 'rejected' }
      : p
    ))
  }

  if (!flags.ai_generation) {
    return (
      <div className="section-pad" style={{ textAlign: 'center', paddingTop: 80 }}>
        <div style={{ fontSize: 48, marginBottom: 16 }} aria-hidden="true">🔧</div>
        <h2>AI Generation Temporarily Unavailable</h2>
        <p style={{ marginTop: 8, color: 'var(--text-2)' }}>We're working on an update. Check back shortly.</p>
      </div>
    )
  }

  return (
    <div>
      {state === 'hero' && (
        <HeroBanner onGetStarted={() => setState('brief')} />
      )}

      {(state === 'brief' || state === 'hero') && state !== 'hero' && (
        <>
          <div className="section-pad">
            <PlatformPicker
              selected={selectedPlatforms}
              onChange={setSelectedPlatforms}
            />
          </div>
          <div className="section-pad" style={{ paddingTop: 0 }}>
            <ContentBriefForm
              value={brief}
              onChange={setBrief}
              onGenerate={handleGenerate}
              error={error}
            />
          </div>
        </>
      )}

      {state === 'generating' && (
        <div className="section-pad" style={{ textAlign: 'center', paddingTop: 80 }}>
          <Spinner size="lg" label="Generating your posts..." />
          <p style={{ marginTop: 16, fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-lg)', color: 'var(--text-1)' }}>
            Crafting your posts...
          </p>
          <p style={{ marginTop: 8, color: 'var(--text-3)', fontSize: 'var(--text-sm)' }}>
            Applying your brand voice across all platforms
          </p>
        </div>
      )}

      {state === 'review' && (
        <div className="section-pad">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-4)' }}>
            <h2>Review & Approve</h2>
            <span className="pill pill--success">✨ AI Generated</span>
          </div>
          <PostReviewList
            posts={posts}
            onApprove={handleApprove}
            onReject={handleReject}
            onReport={handleReport}
          />
          <button
            onClick={() => setShowSchedule(true)}
            disabled={!posts.some(p => p.status === 'approved')}
            style={{
              width: '100%',
              background: 'var(--accent)',
              color: 'white',
              border: 'none',
              borderRadius: 'var(--radius-md)',
              padding: 'var(--space-4)',
              fontFamily: 'var(--font-display)',
              fontWeight: 700,
              fontSize: 'var(--text-md)',
              cursor: 'pointer',
              minHeight: 56,
              marginTop: 'var(--space-4)',
              opacity: posts.some(p => p.status === 'approved') ? 1 : 0.5,
            }}
          >
            📅 Schedule All Approved
          </button>
        </div>
      )}

      {showSchedule && (
        <ScheduleSheet
          posts={posts.filter(p => p.status === 'approved')}
          onPublish={() => {
            setShowSchedule(false)
            setState('scheduled')
          }}
          onClose={() => setShowSchedule(false)}
        />
      )}

      {state === 'scheduled' && (
        <div className="section-pad" style={{ textAlign: 'center', paddingTop: 80 }}>
          <div style={{ fontSize: 64, marginBottom: 16 }} aria-hidden="true">🎉</div>
          <h2>Posts Scheduled!</h2>
          <p style={{ color: 'var(--text-2)', marginTop: 8 }}>Check the Plan tab to see your content calendar.</p>
          <button
            onClick={() => { setState('hero'); setPosts([]); }}
            style={{
              marginTop: 24, background: 'var(--brand)', color: 'white',
              border: 'none', borderRadius: 'var(--radius-md)', padding: 'var(--space-4) var(--space-6)',
              fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer', minHeight: 52,
            }}
          >
            Create Another ✨
          </button>
        </div>
      )}
    </div>
  )
}
