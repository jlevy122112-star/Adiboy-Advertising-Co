import { useState } from 'react'
import type { GeneratedPost } from '../../types'

interface Props {
  posts: GeneratedPost[]
  onPublish: () => void
  onClose: () => void
}

const TIME_OPTIONS = [
  { id: 'now',  label: 'Now',      sub: 'Post immediately' },
  { id: '9am',  label: '9:00 AM',  sub: 'Best for engagement' },
  { id: '12pm', label: '12:30 PM', sub: 'Lunch scroll peak' },
  { id: '6pm',  label: '6:00 PM',  sub: 'Evening peak hour' },
]

export function ScheduleSheet({ posts, onPublish, onClose }: Props) {
  const [selected, setSelected] = useState('now')

  return (
    <div
      style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        background: 'var(--card)',
        borderRadius: 'var(--radius-xl) var(--radius-xl) 0 0',
        padding: 'var(--space-5)',
        zIndex: 'var(--z-modal)',
        animation: 'slideUp var(--duration-base) var(--ease-default)',
        borderTop: '0.5px solid var(--border)',
      }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="schedule-title"
    >
      <div style={{ width: 40, height: 4, borderRadius: 'var(--radius-full)', background: 'var(--border)', margin: '0 auto var(--space-4)' }} aria-hidden="true" />
      <h3 id="schedule-title" style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'var(--text-xl)', color: 'var(--text-1)', marginBottom: 'var(--space-2)' }}>
        Schedule your posts
      </h3>
      <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-2)', marginBottom: 'var(--space-4)' }}>
        AI recommends posting at these times for maximum reach:
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-2)', marginBottom: 'var(--space-4)' }}>
        {TIME_OPTIONS.map(opt => (
          <button
            key={opt.id}
            onClick={() => setSelected(opt.id)}
            aria-pressed={selected === opt.id}
            style={{
              padding: 'var(--space-3)',
              borderRadius: 'var(--radius-md)',
              border: `1.5px solid ${selected === opt.id ? 'var(--brand)' : 'var(--border)'}`,
              background: selected === opt.id ? 'var(--brand-light)' : 'var(--card)',
              textAlign: 'center', cursor: 'pointer',
              transition: 'all var(--duration-fast)',
              minHeight: 'var(--touch-target)',
            }}
          >
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'var(--text-md)', color: selected === opt.id ? 'var(--brand)' : 'var(--text-1)' }}>{opt.label}</div>
            <div style={{ fontSize: 'var(--text-xs)', color: selected === opt.id ? 'var(--brand)' : 'var(--text-3)', marginTop: 2 }}>{opt.sub}</div>
          </button>
        ))}
      </div>

      <button
        onClick={onPublish}
        style={{
          width: '100%', background: 'var(--accent)', color: 'white',
          border: 'none', borderRadius: 'var(--radius-md)', padding: 'var(--space-4)',
          fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'var(--text-md)',
          cursor: 'pointer', minHeight: 52,
        }}
      >
        🚀 Publish {posts.length} Post{posts.length !== 1 ? 's' : ''}
      </button>

      <button
        onClick={onClose}
        style={{
          width: '100%', background: 'transparent', border: 'none',
          color: 'var(--text-3)', fontSize: 'var(--text-sm)',
          cursor: 'pointer', padding: 'var(--space-3)', marginTop: 'var(--space-2)',
          minHeight: 'var(--touch-target)',
        }}
        aria-label="Close schedule sheet"
      >
        Cancel
      </button>
    </div>
  )
}
