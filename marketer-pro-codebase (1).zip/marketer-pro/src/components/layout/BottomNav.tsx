import type { TabName } from '../../types'

interface BottomNavProps {
  activeTab: TabName
  onTabChange: (tab: TabName) => void
}

const TABS: { id: TabName; label: string; icon: string; ariaLabel: string }[] = [
  { id: 'create',   label: 'Create',  icon: '✨', ariaLabel: 'Create tab — generate social media posts' },
  { id: 'plan',     label: 'Plan',    icon: '📅', ariaLabel: 'Plan tab — schedule and manage content calendar' },
  { id: 'analyze',  label: 'Analyze', icon: '📊', ariaLabel: 'Analyze tab — view performance analytics' },
  { id: 'settings', label: 'Settings',icon: '⚙️', ariaLabel: 'Settings tab — manage account and brand profile' },
]

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  return (
    <nav
      role="tablist"
      aria-label="Main navigation"
      style={{
        height: 'var(--nav-height)',
        background: 'var(--card)',
        borderTop: '0.5px solid var(--border)',
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        alignItems: 'center',
        flexShrink: 0,
        paddingBottom: 8,
      }}
    >
      {TABS.map(tab => {
        const isActive = activeTab === tab.id
        return (
          <button
            key={tab.id}
            role="tab"
            aria-selected={isActive}
            aria-label={tab.ariaLabel}
            onClick={() => onTabChange(tab.id)}
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 3,
              padding: '8px 4px 4px',
              minHeight: 'var(--touch-target)',
              transition: 'all var(--duration-fast)',
              color: isActive ? 'var(--brand)' : 'var(--text-3)',
            }}
          >
            <span style={{ fontSize: 22 }} aria-hidden="true">{tab.icon}</span>
            {/* Active pip */}
            <span
              style={{
                width: 4,
                height: 4,
                borderRadius: '50%',
                background: isActive ? 'var(--brand)' : 'transparent',
                transition: 'background var(--duration-fast)',
              }}
              aria-hidden="true"
            />
            <span
              style={{
                fontSize: 'var(--text-xs)',
                fontWeight: isActive ? 700 : 500,
                letterSpacing: '0.3px',
              }}
            >
              {tab.label}
            </span>
          </button>
        )
      })}
    </nav>
  )
}
