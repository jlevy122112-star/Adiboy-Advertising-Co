import { useState } from 'react'
import { TopBar } from './TopBar'
import { BottomNav } from './BottomNav'
import { CreateTab } from '../create/CreateTab'
import { PlanTab } from '../plan/PlanTab'
import { AnalyzeTab } from '../analyze/AnalyzeTab'
import { SettingsTab } from '../settings/SettingsTab'
import type { TabName } from '../../types'

export function AppShell() {
  const [activeTab, setActiveTab] = useState<TabName>('create')

  return (
    <div className="app-shell">
      <TopBar />
      <main className="screen-area" id="main-content" role="main">
        {activeTab === 'create'   && <CreateTab />}
        {activeTab === 'plan'     && <PlanTab />}
        {activeTab === 'analyze'  && <AnalyzeTab />}
        {activeTab === 'settings' && <SettingsTab />}
      </main>
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  )
}
