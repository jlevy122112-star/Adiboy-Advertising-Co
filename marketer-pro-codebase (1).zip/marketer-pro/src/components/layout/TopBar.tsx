import { useAuth } from '../../hooks/useAuth'

export function TopBar() {
  const { user } = useAuth()
  const initials = user?.name
    ? user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
    : 'MP'

  return (
    <header
      style={{
        height: 'var(--topbar-height)',
        background: 'var(--card)',
        borderBottom: '0.5px solid var(--border)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 var(--space-5)',
        flexShrink: 0,
      }}
    >
      <div
        style={{
          fontFamily: 'var(--font-display)',
          fontWeight: 800,
          fontSize: 'var(--text-xl)',
          color: 'var(--brand)',
          letterSpacing: '-0.5px',
        }}
        aria-label="Marketer Pro"
      >
        Marketer<span style={{ color: 'var(--text-1)' }}>Pro</span>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
        {/* Notification bell */}
        <button
          aria-label="Notifications"
          style={{
            position: 'relative',
            minHeight: 'var(--touch-target)',
            minWidth: 'var(--touch-target)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--text-2)',
            fontSize: 22,
          }}
        >
          🔔
        </button>

        {/* Avatar */}
        <button
          aria-label="Account settings"
          style={{
            width: 36,
            height: 36,
            minHeight: 'var(--touch-target)',
            minWidth: 'var(--touch-target)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, var(--brand), var(--brand-mid))',
            color: 'white',
            fontFamily: 'var(--font-display)',
            fontWeight: 600,
            fontSize: 'var(--text-sm)',
          }}
        >
          {initials}
        </button>
      </div>
    </header>
  )
}
