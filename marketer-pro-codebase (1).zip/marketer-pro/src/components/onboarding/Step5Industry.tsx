import { INDUSTRY_LABELS } from '../../constants'
import type { Industry } from '../../types'

interface Props { value?: Industry; onChange: (v: string) => void }

export function Step5Industry({ value, onChange }: Props) {
  return (
    <div className="animate-fade-up">
      <p style={{ fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--brand)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 'var(--space-2)' }}>Step 5 of 5</p>
      <h1 style={{ fontSize: 'var(--text-3xl)', fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--text-1)', marginBottom: 'var(--space-2)' }}>What industry are you in?</h1>
      <p style={{ color: 'var(--text-2)', marginBottom: 'var(--space-6)' }}>Almost done! This shapes your content style and hashtag strategy.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
        {(Object.entries(INDUSTRY_LABELS) as [Industry, string][]).map(([id, label]) => {
          const selected = value === id
          return (
            <button
              key={id}
              role="radio"
              aria-checked={selected}
              onClick={() => onChange(id)}
              style={{
                display: 'flex', alignItems: 'center', gap: 'var(--space-3)',
                padding: 'var(--space-4)', borderRadius: 'var(--radius-md)',
                border: `1.5px solid ${selected ? 'var(--brand)' : 'var(--border)'}`,
                background: selected ? 'var(--brand-light)' : 'var(--card)',
                cursor: 'pointer', textAlign: 'left', minHeight: 56,
                transition: 'all var(--duration-fast)',
              }}
            >
              <div style={{
                width: 22, height: 22, borderRadius: '50%', flexShrink: 0,
                border: `2px solid ${selected ? 'var(--brand)' : 'var(--border)'}`,
                background: selected ? 'var(--brand)' : 'transparent',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'white', fontSize: 11, fontWeight: 700,
              }}>
                {selected && '✓'}
              </div>
              <span style={{ fontWeight: 500, color: 'var(--text-1)', fontSize: 'var(--text-base)' }}>{label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
