import type { BusinessType } from '../../types'

const OPTIONS: { value: BusinessType; label: string; sub: string }[] = [
  { value: 'product',  label: 'Product',  sub: 'Physical or digital products you sell' },
  { value: 'service',  label: 'Service',  sub: 'Consulting, coaching, or professional services' },
  { value: 'both',     label: 'Both',     sub: 'Products and services combined' },
]

interface Props { value?: BusinessType; onChange: (v: string) => void }

export function Step1BusinessType({ value, onChange }: Props) {
  return (
    <div className="animate-fade-up">
      <p style={{ fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--brand)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 'var(--space-2)' }}>Step 1 of 5</p>
      <h1 style={{ fontSize: 'var(--text-3xl)', fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--text-1)', marginBottom: 'var(--space-2)' }}>What are you promoting?</h1>
      <p style={{ color: 'var(--text-2)', marginBottom: 'var(--space-6)' }}>Help us understand your business so every post sounds exactly like you.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
        {OPTIONS.map(opt => {
          const selected = value === opt.value
          return (
            <button
              key={opt.value}
              role="radio"
              aria-checked={selected}
              onClick={() => onChange(opt.value)}
              style={{
                display: 'flex', alignItems: 'center', gap: 'var(--space-3)',
                padding: 'var(--space-4)', borderRadius: 'var(--radius-md)',
                border: `1.5px solid ${selected ? 'var(--brand)' : 'var(--border)'}`,
                background: selected ? 'var(--brand-light)' : 'var(--card)',
                cursor: 'pointer', textAlign: 'left', minHeight: 72,
                transition: 'all var(--duration-fast)',
              }}
            >
              <div style={{
                width: 22, height: 22, borderRadius: '50%', flexShrink: 0,
                border: `2px solid ${selected ? 'var(--brand)' : 'var(--border)'}`,
                background: selected ? 'var(--brand)' : 'transparent',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'white', fontSize: 11, fontWeight: 700,
              }}>
                {selected && '✓'}
              </div>
              <div>
                <div style={{ fontWeight: 500, color: 'var(--text-1)', fontSize: 'var(--text-md)' }}>{opt.label}</div>
                <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-3)', marginTop: 2 }}>{opt.sub}</div>
              </div>
            </button>
          )
        })}
      </div>
    </div>
  )
}
