/**
 * AI CONSENT MODAL
 * Required by:
 * - Apple Guideline 5.1.2(i) — must name OpenAI, describe data sent, get explicit permission
 * - Google Play User Data Policy — Prominent Disclosure requirement
 * - Must appear BEFORE any brand data is sent to OpenAI
 * - Cannot be skipped or auto-dismissed
 */
interface AIConsentModalProps {
  onAccept: () => void
  onDecline: () => void
}

export function AIConsentModal({ onAccept, onDecline }: AIConsentModalProps) {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="ai-consent-title"
      style={{
        position: 'absolute',
        inset: 0,
        background: 'rgba(26, 16, 51, 0.8)',
        display: 'flex',
        alignItems: 'flex-end',
        zIndex: 'var(--z-modal)',
      }}
    >
      <div
        style={{
          background: 'var(--card)',
          borderRadius: 'var(--radius-xl) var(--radius-xl) 0 0',
          padding: 'var(--space-6)',
          width: '100%',
          animation: 'slideUp var(--duration-base) var(--ease-default)',
        }}
      >
        <div style={{ textAlign: 'center', marginBottom: 'var(--space-4)' }}>
          <div style={{ fontSize: 48, marginBottom: 'var(--space-3)' }} aria-hidden="true">🤖</div>
          <h2
            id="ai-consent-title"
            style={{
              fontFamily: 'var(--font-display)',
              fontWeight: 800,
              fontSize: 'var(--text-2xl)',
              color: 'var(--text-1)',
              marginBottom: 'var(--space-3)',
            }}
          >
            One quick thing
          </h2>
        </div>

        <p style={{ color: 'var(--text-2)', lineHeight: 1.6, marginBottom: 'var(--space-4)', textAlign: 'center' }}>
          Marketer Pro uses <strong style={{ color: 'var(--text-1)' }}>OpenAI</strong> to generate your content.
          Your <strong style={{ color: 'var(--text-1)' }}>brand name, industry, and content briefs</strong> are
          sent to OpenAI to create posts that sound like you.
        </p>

        <div style={{
          background: 'var(--brand-light)',
          borderRadius: 'var(--radius-md)',
          padding: 'var(--space-4)',
          marginBottom: 'var(--space-5)',
        }}>
          <p style={{ fontSize: 'var(--text-sm)', color: 'var(--brand)', lineHeight: 1.5 }}>
            Your data is used only to generate content for your brand.
            We never sell your data. You can request deletion at any time in Settings.
          </p>
        </div>

        <button
          onClick={onAccept}
          autoFocus
          style={{
            width: '100%',
            background: 'var(--brand)',
            color: 'white',
            border: 'none',
            borderRadius: 'var(--radius-md)',
            padding: 'var(--space-4)',
            fontFamily: 'var(--font-display)',
            fontWeight: 700,
            fontSize: 'var(--text-md)',
            cursor: 'pointer',
            minHeight: 52,
            marginBottom: 'var(--space-3)',
          }}
        >
          I understand — let's go ✨
        </button>

        <button
          onClick={onDecline}
          style={{
            width: '100%',
            background: 'transparent',
            color: 'var(--text-3)',
            border: 'none',
            padding: 'var(--space-3)',
            fontSize: 'var(--text-sm)',
            cursor: 'pointer',
            minHeight: 'var(--touch-target)',
          }}
        >
          Not now
        </button>
      </div>
    </div>
  )
}
