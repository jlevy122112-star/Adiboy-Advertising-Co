import type { BrandProfile } from '../../types'

interface Props { data: Partial<BrandProfile>; onChange: (u: Partial<BrandProfile>) => void }

export function Step3ProblemSolution({ data, onChange }: Props) {
  return (
    <div className="animate-fade-up">
      <p style={{ fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--brand)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 'var(--space-2)' }}>Step 3 of 5</p>
      <h1 style={{ fontSize: 'var(--text-3xl)', fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--text-1)', marginBottom: 'var(--space-2)' }}>What problem do you solve?</h1>
      <p style={{ color: 'var(--text-2)', marginBottom: 'var(--space-6)' }}>The AI uses this to write content that speaks directly to your customer's pain.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
        {[
          { id: 'problem', label: 'Their problem before finding you', field: 'customerProblem' as keyof BrandProfile, placeholder: "e.g. Spending hours writing social posts with no real strategy..." },
          { id: 'solution', label: 'Your solution', field: 'ourSolution' as keyof BrandProfile, placeholder: "e.g. AI-powered content that sounds like you, posted in seconds..." },
          { id: 'outcome', label: 'The outcome they get', field: 'customerOutcome' as keyof BrandProfile, placeholder: "e.g. More followers, more leads, less time on content..." },
        ].map(item => (
          <div key={item.id}>
            <label htmlFor={item.id} style={{ display: 'block', fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6 }}>{item.label}</label>
            <textarea
              id={item.id}
              placeholder={item.placeholder}
              value={(data[item.field] as string) ?? ''}
              onChange={e => onChange({ [item.field]: e.target.value })}
              style={{ resize: 'none', height: 80 }}
            />
          </div>
        ))}
      </div>
    </div>
  )
}
