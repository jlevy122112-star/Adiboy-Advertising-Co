import type { BrandProfile } from '../../types'

interface Props { data: Partial<BrandProfile>; onChange: (u: Partial<BrandProfile>) => void }

export function Step4ContactInfo({ data, onChange }: Props) {
  return (
    <div className="animate-fade-up">
      <p style={{ fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--brand)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 'var(--space-2)' }}>Step 4 of 5</p>
      <h1 style={{ fontSize: 'var(--text-3xl)', fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--text-1)', marginBottom: 'var(--space-2)' }}>How do people reach you?</h1>
      <p style={{ color: 'var(--text-2)', marginBottom: 'var(--space-6)' }}>We'll include these in your posts so customers can always find you.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
        {[
          { id: 'website', label: 'Website URL', field: 'website' as keyof BrandProfile, placeholder: 'https://yourwebsite.com', type: 'url' },
          { id: 'phone', label: 'Phone Number', field: 'phone' as keyof BrandProfile, placeholder: '+1 (555) 000-0000', type: 'tel' },
          { id: 'email', label: 'Email Address', field: 'email' as keyof BrandProfile, placeholder: 'hello@yourbrand.com', type: 'email' },
          { id: 'instagram', label: 'Instagram Handle', field: undefined, placeholder: '@yourbrand', type: 'text' },
          { id: 'address', label: 'Physical Address (optional)', field: 'address' as keyof BrandProfile, placeholder: '123 Main St, City, State', type: 'text' },
        ].map(item => (
          <div key={item.id}>
            <label htmlFor={item.id} style={{ display: 'block', fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6 }}>{item.label}</label>
            <input
              id={item.id}
              type={item.type}
              placeholder={item.placeholder}
              value={item.field ? ((data[item.field] as string) ?? '') : (data.socialHandles?.instagram ?? '')}
              onChange={e => {
                if (item.field) {
                  onChange({ [item.field]: e.target.value })
                } else {
                  onChange({ socialHandles: { ...data.socialHandles, instagram: e.target.value } })
                }
              }}
              autoComplete={item.type === 'email' ? 'email' : item.type === 'tel' ? 'tel' : 'off'}
            />
          </div>
        ))}
      </div>
    </div>
  )
}
