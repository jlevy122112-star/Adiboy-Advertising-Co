import { useState } from 'react'
import { supabase } from '../../api/supabase'
import { useAuth } from '../../hooks/useAuth'
import { Step1BusinessType } from './Step1BusinessType'
import { Step2BrandIdentity } from './Step2BrandIdentity'
import { Step3ProblemSolution } from './Step3ProblemSolution'
import { Step4ContactInfo } from './Step4ContactInfo'
import { Step5Industry } from './Step5Industry'
import { AIConsentModal } from './AIConsentModal'
import type { BrandProfile, OnboardingStep, BusinessType, Industry } from '../../types'

const TOTAL_STEPS = 5

export function OnboardingFlow() {
  const { user } = useAuth()
  const [step, setStep] = useState<OnboardingStep>(1)
  const [showAIConsent, setShowAIConsent] = useState(false)
  const [saving, setSaving] = useState(false)
  const [data, setData] = useState<Partial<BrandProfile>>({
    voiceKeywords: [],
    socialHandles: {},
  })

  function updateData(updates: Partial<BrandProfile>) {
    setData(prev => ({ ...prev, ...updates }))
  }

  function handleNext() {
    if (step < TOTAL_STEPS) {
      setStep(prev => (prev + 1) as OnboardingStep)
    } else {
      // Final step — show AI consent before saving
      setShowAIConsent(true)
    }
  }

  async function handleAIConsentAccepted() {
    setShowAIConsent(false)
    await saveProfile()
  }

  async function saveProfile() {
    if (!user) return
    setSaving(true)
    try {
      const { error: profileError } = await supabase
        .from('brand_profiles')
        .insert({
          user_id: user.id,
          ...data,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })

      if (!profileError) {
        await supabase
          .from('users')
          .update({ onboarding_complete: true })
          .eq('id', user.id)

        // Reload the page to trigger AppShell
        window.location.reload()
      }
    } finally {
      setSaving(false)
    }
  }

  const progress = (step / TOTAL_STEPS) * 100

  return (
    <div className="app-shell" style={{ background: 'var(--card)' }}>
      {/* Progress bar */}
      <div style={{ height: 4, background: 'var(--brand-light)', flexShrink: 0 }}>
        <div
          style={{
            height: '100%',
            width: `${progress}%`,
            background: 'var(--brand)',
            borderRadius: 'var(--radius-full)',
            transition: 'width var(--duration-base) var(--ease-default)',
          }}
          role="progressbar"
          aria-valuenow={step}
          aria-valuemin={1}
          aria-valuemax={TOTAL_STEPS}
          aria-label={`Onboarding step ${step} of ${TOTAL_STEPS}`}
        />
      </div>

      {/* Step content */}
      <div className="screen-area" style={{ padding: 'var(--space-6) var(--space-6) var(--space-4)' }}>
        {step === 1 && (
          <Step1BusinessType
            value={data.businessType}
            onChange={val => updateData({ businessType: val as BusinessType })}
          />
        )}
        {step === 2 && (
          <Step2BrandIdentity
            data={data}
            onChange={updateData}
          />
        )}
        {step === 3 && (
          <Step3ProblemSolution
            data={data}
            onChange={updateData}
          />
        )}
        {step === 4 && (
          <Step4ContactInfo
            data={data}
            onChange={updateData}
          />
        )}
        {step === 5 && (
          <Step5Industry
            value={data.industry}
            onChange={val => updateData({ industry: val as Industry })}
          />
        )}
      </div>

      {/* Footer */}
      <div style={{
        padding: 'var(--space-4) var(--space-6) var(--space-6)',
        background: 'var(--card)',
        borderTop: '0.5px solid var(--border)',
        flexShrink: 0,
      }}>
        <button
          onClick={handleNext}
          disabled={saving}
          aria-busy={saving}
          style={{
            width: '100%',
            background: 'var(--brand)',
            color: 'white',
            border: 'none',
            borderRadius: 'var(--radius-lg)',
            padding: 'var(--space-4)',
            fontFamily: 'var(--font-display)',
            fontWeight: 700,
            fontSize: 'var(--text-md)',
            cursor: saving ? 'wait' : 'pointer',
            minHeight: 56,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 'var(--space-2)',
            transition: 'background var(--duration-fast)',
          }}
        >
          {saving ? 'Setting up your account...' : step === TOTAL_STEPS ? "Let's Go! ✨" : 'Continue →'}
        </button>
        <p style={{
          textAlign: 'center',
          marginTop: 'var(--space-3)',
          fontSize: 'var(--text-sm)',
          color: 'var(--text-3)',
        }}>
          Step {step} of {TOTAL_STEPS}
        </p>
      </div>

      {/* AI Consent Modal — required by Apple 5.1.2(i) and Google Prominent Disclosure */}
      {showAIConsent && (
        <AIConsentModal
          onAccept={handleAIConsentAccepted}
          onDecline={() => setShowAIConsent(false)}
        />
      )}
    </div>
  )
}
