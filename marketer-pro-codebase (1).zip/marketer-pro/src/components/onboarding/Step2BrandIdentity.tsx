import type { BrandProfile } from '../../types'

interface Props { data: Partial<BrandProfile>; onChange: (u: Partial<BrandProfile>) => void }

export function Step2BrandIdentity({ data, onChange }: Props) {
  return (
    <div className="animate-fade-up">
      <p style={{ fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--brand)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 'var(--space-2)' }}>Step 2 of 5</p>
      <h1 style={{ fontSize: 'var(--text-3xl)', fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--text-1)', marginBottom: 'var(--space-2)' }}>Who are you?</h1>
      <p style={{ color: 'var(--text-2)', marginBottom: 'var(--space-6)' }}>Your brand identity shapes every post the AI creates for you.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
        <div>
          <label htmlFor="brand-name" style={{ display: 'block', fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6 }}>Brand Name *</label>
          <input id="brand-name" type="text" placeholder="e.g. Sunrise Coffee Co." value={data.name ?? ''} onChange={e => onChange({ name: e.target.value })} aria-required="true" />
        </div>
        <div>
          <label htmlFor="tagline" style={{ display: 'block', fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6 }}>Tagline</label>
          <input id="tagline" type="text" placeholder="e.g. Fuel your morning ritual" value={data.tagline ?? ''} onChange={e => onChange({ tagline: e.target.value })} />
        </div>
        <div>
          <label htmlFor="brand-color" style={{ display: 'block', fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6 }}>Primary Brand Color</label>
          <div style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'center' }}>
            <input id="brand-color-picker" type="color" value={data.primaryColor ?? '#7C3AED'} onChange={e => onChange({ primaryColor: e.target.value })} style={{ width: 48, height: 48, padding: 2, borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)', cursor: 'pointer' }} aria-label="Pick brand color" />
            <input id="brand-color" type="text" placeholder="#7C3AED" value={data.primaryColor ?? ''} onChange={e => onChange({ primaryColor: e.target.value })} style={{ flex: 1 }} />
          </div>
        </div>
        <div>
          <label htmlFor="voice-keywords" style={{ display: 'block', fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6 }}>3 Words That Describe Your Brand</label>
          <input id="voice-keywords" type="text" placeholder="e.g. Bold, Friendly, Inspiring" value={data.voiceKeywords?.join(', ') ?? ''} onChange={e => onChange({ voiceKeywords: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })} />
        </div>
        <div>
          <label style={{ display: 'block', fontSize: 'var(--text-xs)', fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6 }}>Brand Logo</label>
          <div
            style={{
              border: '1.5px dashed var(--border)', borderRadius: 'var(--radius-md)',
              padding: 'var(--space-5)', textAlign: 'center', cursor: 'pointer',
              background: 'var(--surface)',
            }}
            role="button"
            aria-label="Upload brand logo. Tap to select an image."
            tabIndex={0}
          >
            <div style={{ fontSize: 32, marginBottom: 8 }} aria-hidden="true">📁</div>
            <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-3)' }}>Upload your logo</p>
            <p style={{ fontSize: 'var(--text-xs)', color: 'var(--text-3)', marginTop: 4 }}>PNG, JPG, or SVG</p>
          </div>
        </div>
      </div>
    </div>
  )
}
