import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './hooks/useAuth'
import { AppShell } from './components/layout/AppShell'
import { OnboardingFlow } from './components/onboarding/OnboardingFlow'
import { AuthPage } from './pages/AuthPage'
import { Spinner } from './components/ui/Spinner'

export default function App() {
  const { user, loading, isAuthenticated } = useAuth()

  if (loading) {
    return (
      <div className="app-shell" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <Spinner size="lg" label="Loading Marketer Pro..." />
          <p style={{ marginTop: 16, color: 'var(--text-3)', fontSize: 'var(--text-sm)' }}>Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/auth"
          element={!isAuthenticated ? <AuthPage /> : <Navigate to="/" replace />}
        />
        <Route
          path="/*"
          element={
            !isAuthenticated
              ? <Navigate to="/auth" replace />
              : user && !(user as any).onboardingComplete
              ? <OnboardingFlow />
              : <AppShell />
          }
        />
      </Routes>
    </BrowserRouter>
  )
}
