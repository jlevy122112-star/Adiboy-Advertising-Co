/* ============================================================
   MARKETER PRO — FEATURE FLAGS HOOK
   Server-side kill switches — every high-risk feature has one
   Disables features without requiring a new app store release
   ============================================================ */
import { useState, useEffect } from 'react';
import { supabase } from '../api/supabase';
import type { FeatureFlags } from '../types';

const DEFAULT_FLAGS: FeatureFlags = {
  ai_generation: true,
  autonomous_mode: true,
  posting_enabled: true,
  feature_post_instagram: true,
  feature_post_facebook: true,
  feature_post_twitter: true,
  feature_post_linkedin: true,
  feature_post_tiktok: true,
  feature_post_youtube: true,
  feature_post_pinterest: true,
  feature_post_snapchat: true,
  feature_analytics: true,
  feature_billing: true,
};

export function useFeatureFlags() {
  const [flags, setFlags] = useState<FeatureFlags>(DEFAULT_FLAGS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFlags();
  }, []);

  async function fetchFlags() {
    try {
      const { data } = await supabase
        .from('feature_flags')
        .select('key, enabled');

      if (data) {
        const overrides = data.reduce((acc, row) => {
          acc[row.key as keyof FeatureFlags] = row.enabled;
          return acc;
        }, {} as Partial<FeatureFlags>);
        setFlags({ ...DEFAULT_FLAGS, ...overrides });
      }
    } catch {
      // Fall back to defaults — never break the app on flag fetch failure
    } finally {
      setLoading(false);
    }
  }

  return { flags, loading };
}
