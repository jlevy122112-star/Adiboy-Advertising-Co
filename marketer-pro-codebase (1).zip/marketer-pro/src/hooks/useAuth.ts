/* ============================================================
   MARKETER PRO — AUTH HOOK
   Single source of truth for auth state across the app
   ============================================================ */
import { useState, useEffect } from 'react';
import type { Session, User as SupabaseUser } from '@supabase/supabase-js';
import { supabase } from '../api/supabase';
import type { User, Plan } from '../types';

interface AuthState {
  user: User | null;
  session: Session | null;
  loading: boolean;
  isAuthenticated: boolean;
}

export function useAuth(): AuthState {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session?.user) {
        fetchUserProfile(session.user);
      } else {
        setLoading(false);
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        setSession(session);
        if (session?.user) {
          await fetchUserProfile(session.user);
        } else {
          setUser(null);
          setLoading(false);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  async function fetchUserProfile(supabaseUser: SupabaseUser) {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', supabaseUser.id)
        .single();

      if (error || !data) {
        // Create profile if it doesn't exist yet
        const newUser: User = {
          id: supabaseUser.id,
          email: supabaseUser.email ?? '',
          name: supabaseUser.user_metadata?.name ?? '',
          plan: 'free' as Plan,
          createdAt: new Date().toISOString(),
        };
        setUser(newUser);
      } else {
        setUser(data as User);
      }
    } catch {
      // Auth failure — do not expose details
    } finally {
      setLoading(false);
    }
  }

  return {
    user,
    session,
    loading,
    isAuthenticated: !!session && !!user,
  };
}
