/* ============================================================
   MARKETER PRO — BRAND PROFILE HOOK
   The ONLY way to access brand data in components
   buildBrandContextForAI() MUST be called in every generation request
   ============================================================ */
import { useState, useEffect } from 'react';
import { supabase } from '../api/supabase';
import type { BrandProfile } from '../types';

export function useBrandProfile(userId: string | undefined) {
  const [profile, setProfile] = useState<BrandProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }
    fetchProfile(userId);
  }, [userId]);

  async function fetchProfile(uid: string) {
    const { data, error } = await supabase
      .from('brand_profiles')
      .select('*')
      .eq('user_id', uid)
      .single();

    if (error) {
      setError(error.message);
    } else {
      setProfile(data as BrandProfile);
    }
    setLoading(false);
  }

  async function updateProfile(updates: Partial<BrandProfile>) {
    if (!profile) return;
    const { data, error } = await supabase
      .from('brand_profiles')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', profile.id)
      .select()
      .single();

    if (!error && data) {
      setProfile(data as BrandProfile);
    }
    return { error };
  }

  return { profile, loading, error, updateProfile, refetch: () => userId && fetchProfile(userId) };
}

// ── BRAND CONTEXT BUILDER ──────────────────────────────────────
// MUST be called in every AI generation request — never call OpenAI without this
export function buildBrandContextForAI(profile: BrandProfile): string {
  return `
BRAND PROFILE:
- Name: ${profile.name}
- Industry: ${profile.industry}
- Business type: ${profile.businessType}
- Tagline: ${profile.tagline ?? 'Not provided'}
- Mission: ${profile.mission ?? 'Not provided'}
- Voice and tone keywords: ${profile.voiceKeywords.join(', ')}
- Target audience: ${profile.targetAudience ?? 'General business audience'}
- Customer problem: ${profile.customerProblem ?? 'Not specified'}
- Our solution: ${profile.ourSolution ?? 'Not specified'}
- Customer outcome: ${profile.customerOutcome ?? 'Not specified'}
- Competitors to differentiate from (do NOT mimic their style): ${
    profile.competitors?.join(', ') ?? 'None specified'
  }
- Website: ${profile.website ?? 'Not provided'}
- Phone: ${profile.phone ?? 'Not provided'}
- Email: ${profile.email ?? 'Not provided'}

CONTENT RULES:
- Always write in the brand voice described by these keywords: ${profile.voiceKeywords.join(', ')}
- Do NOT mimic competitor styles
- Do NOT make unverifiable claims
- Do NOT generate content that is offensive, discriminatory, or misleading
- Content MUST comply with each platform's community guidelines
  `.trim();
}
