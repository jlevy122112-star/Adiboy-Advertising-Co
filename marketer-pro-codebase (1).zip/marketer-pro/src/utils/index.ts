/* ============================================================
   MARKETER PRO — UTILITY FUNCTIONS
   ============================================================ */

// Format numbers for display (48200 → "48.2K")
export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return n.toString()
}

// Format date for display — always use full format for international users
export function formatDate(dateStr: string): string {
  return new Intl.DateTimeFormat('en-US', {
    month: 'long', day: 'numeric', year: 'numeric',
  }).format(new Date(dateStr))
}

// Format currency — always show full amount (never monthly breakdown of annual)
export function formatCurrency(cents: number, currency = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency', currency, minimumFractionDigits: 0,
  }).format(cents / 100)
}

// Truncate text with ellipsis
export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength - 3) + '...'
}

// Count characters in a post (for platform char limits)
export function countChars(content: string, hashtags: string[]): number {
  const hashtagStr = hashtags.length > 0 ? '\n\n' + hashtags.map(h => `#${h}`).join(' ') : ''
  return (content + hashtagStr).length
}

// Get user-friendly error message — never expose technical details
export function getUserErrorMessage(error: unknown): string {
  if (typeof error === 'string') return error
  if (error instanceof Error) {
    // Map technical errors to user-friendly messages
    if (error.message.includes('network') || error.message.includes('fetch')) {
      return 'Connection error. Please check your internet and try again.'
    }
    if (error.message.includes('auth') || error.message.includes('401')) {
      return 'Session expired. Please sign in again.'
    }
    if (error.message.includes('429')) {
      return 'Too many requests. Please wait a moment and try again.'
    }
  }
  return 'Something went wrong. Please try again.'
}

// Generate a unique ID for client-side use
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
}
