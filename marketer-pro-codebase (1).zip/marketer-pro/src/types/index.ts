/* ============================================================
   MARKETER PRO — CORE TYPE DEFINITIONS
   ============================================================ */

export interface User {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
  plan: Plan;
  createdAt: string;
  onboardingComplete?: boolean;
}

export type Plan = 'free' | 'pro' | 'enterprise';

export interface BrandProfile {
  id: string;
  userId: string;
  name: string;
  tagline?: string;
  mission?: string;
  industry: Industry;
  businessType: BusinessType;
  primaryColor: string;
  accentColor?: string;
  logoUrl?: string;
  voiceKeywords: string[];
  targetAudience?: string;
  competitors?: string[];
  customerProblem?: string;
  ourSolution?: string;
  customerOutcome?: string;
  phone?: string;
  email?: string;
  website?: string;
  address?: string;
  socialHandles: Partial<Record<Platform, string>>;
  bestContentExamples?: string[];
  createdAt: string;
  onboardingComplete?: boolean;
  updatedAt: string;
}

export type Industry =
  | 'tech_saas' | 'retail_ecommerce' | 'health_wellness'
  | 'creative_agency' | 'food_beverage' | 'professional_services'
  | 'real_estate' | 'education' | 'nonprofit' | 'other';

export type BusinessType = 'product' | 'service' | 'both';

export type Platform =
  | 'instagram' | 'facebook' | 'twitter' | 'linkedin'
  | 'tiktok' | 'youtube' | 'pinterest' | 'snapchat';

export const ALL_PLATFORMS: Platform[] = [
  'instagram', 'facebook', 'twitter', 'linkedin',
  'tiktok', 'youtube', 'pinterest', 'snapchat',
];

export interface PlatformConnection {
  id: string;
  userId: string;
  platform: Platform;
  platformUsername: string;
  platformUserId: string;
  backgroundPostingEnabled: boolean;
  connectedAt: string;
  lastUsedAt?: string;
}

export type ContentGoal =
  | 'drive_traffic' | 'generate_leads' | 'build_awareness'
  | 'announce_promotion' | 'educate_audience' | 'build_community';

export type HashtagStrategy =
  | 'broad_reach' | 'niche_focused' | 'trending_only' | 'no_hashtags';

export type PostUrgency = 'normal' | 'urgent' | 'soft_sell';

export interface ContentBrief {
  platforms: Platform[];
  topic: string;
  goal: ContentGoal;
  callToAction: string;
  hashtagStrategy: HashtagStrategy;
  urgency: PostUrgency;
  audienceExclusions?: string;
  responseDeadline?: string;
  showLogo?: boolean;
}

export type PostStatus =
  | 'draft' | 'approved' | 'rejected' | 'scheduled' | 'published' | 'failed';

export type PostRating = 'thumbs_up' | 'thumbs_down' | null;

export type FlagReason = 'wrong_tone' | 'factually_incorrect' | 'off_brand' | 'offensive';

export interface GeneratedPost {
  id: string;
  userId: string;
  brandProfileId: string;
  platform: Platform;
  content: string;
  hashtags: string[];
  charCount: number;
  status: PostStatus;
  scheduledAt?: string;
  publishedAt?: string;
  rating: PostRating;
  flagReason?: FlagReason;
  reportedAt?: string;
  briefSnapshot: ContentBrief;
  createdAt: string;
  onboardingComplete?: boolean;
  updatedAt: string;
}

export interface PostAnalytics {
  postId: string;
  platform: Platform;
  reach: number;
  impressions: number;
  likes: number;
  comments: number;
  shares: number;
  clicks: number;
  engagementRate: number;
  recordedAt: string;
}

export interface PerformanceSummary {
  totalReach: number;
  totalEngagement: number;
  avgEngagementRate: number;
  totalPosts: number;
  totalClicks: number;
  reachChange: number;
  engagementChange: number;
  platformBreakdown: Partial<Record<Platform, number>>;
  period: 'week' | 'month' | 'quarter';
}

export type SubscriptionStatus =
  | 'active' | 'trialing' | 'past_due' | 'canceled' | 'expired';

export type BillingInterval = 'month' | 'year';
export type PaymentProvider = 'stripe' | 'apple' | 'amazon';

export interface Subscription {
  id: string;
  userId: string;
  plan: Plan;
  status: SubscriptionStatus;
  interval: BillingInterval;
  provider: PaymentProvider;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
  trialEnd?: string;
  createdAt: string;
  onboardingComplete?: boolean;
}

export interface FeatureFlags {
  ai_generation: boolean;
  autonomous_mode: boolean;
  posting_enabled: boolean;
  feature_post_instagram: boolean;
  feature_post_facebook: boolean;
  feature_post_twitter: boolean;
  feature_post_linkedin: boolean;
  feature_post_tiktok: boolean;
  feature_post_youtube: boolean;
  feature_post_pinterest: boolean;
  feature_post_snapchat: boolean;
  feature_analytics: boolean;
  feature_billing: boolean;
}

export type TabName = 'create' | 'plan' | 'analyze' | 'settings';
export type OnboardingStep = 1 | 2 | 3 | 4 | 5;

export interface OnboardingState {
  currentStep: OnboardingStep;
  completed: boolean;
  data: Partial<BrandProfile>;
}

export interface ApiResponse<T> {
  data: T | null;
  error: string | null;
  success: boolean;
}

export interface AppError {
  code: string;
  message: string;
  technical?: string;
}
