/* ============================================================
   MARKETER PRO — API CLIENT
   All calls to the Railway backend API
   Never exposes API keys — all secrets are server-side
   ============================================================ */
import { API_BASE_URL } from '../constants';
import type { ApiResponse } from '../types';

class ApiClient {
  private baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    try {
      const { data: session } = await import('./supabase').then(m =>
        m.supabase.auth.getSession()
      );
      const token = session?.session?.access_token;

      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
          ...options.headers,
        },
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({ message: 'Request failed' }));
        return {
          data: null,
          error: error.message || `HTTP ${response.status}`,
          success: false,
        };
      }

      const data = await response.json();
      return { data, error: null, success: true };
    } catch (err) {
      // Never log sensitive request details to console in production
      const message = err instanceof Error ? err.message : 'Network error';
      return { data: null, error: message, success: false };
    }
  }

  get<T>(endpoint: string) {
    return this.request<T>(endpoint, { method: 'GET' });
  }

  post<T>(endpoint: string, body: unknown) {
    return this.request<T>(endpoint, {
      method: 'POST',
      body: JSON.stringify(body),
    });
  }

  put<T>(endpoint: string, body: unknown) {
    return this.request<T>(endpoint, {
      method: 'PUT',
      body: JSON.stringify(body),
    });
  }

  delete<T>(endpoint: string) {
    return this.request<T>(endpoint, { method: 'DELETE' });
  }
}

export const api = new ApiClient(API_BASE_URL || '');
