import { useState } from 'react'
import { supabase } from '../api/supabase'

type AuthMode = 'login' | 'signup' | 'forgot'

export function AuthPage() {
  const [mode, setMode] = useState<AuthMode>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<{ type: 'error' | 'success'; text: string } | null>(null)

  async function handleSubmit() {
    setLoading(true)
    setMessage(null)

    try {
      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) setMessage({ type: 'error', text: error.message })
      } else if (mode === 'signup') {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { data: { name } },
        })
        if (error) setMessage({ type: 'error', text: error.message })
        else setMessage({ type: 'success', text: 'Check your email to verify your account.' })
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email)
        if (error) setMessage({ type: 'error', text: error.message })
        else setMessage({ type: 'success', text: 'Password reset email sent. Check your inbox.' })
      }
    } finally {
      setLoading(false)
    }
  }

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: 'var(--text-2)',
    textTransform: 'uppercase' as const,
    letterSpacing: '0.5px',
    marginBottom: 6,
  }

  return (
    <div className="app-shell" style={{ background: 'var(--card)', justifyContent: 'center' }}>
      <div style={{ padding: 'var(--space-8) var(--space-6)' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 'var(--space-8)' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'var(--text-4xl)', color: 'var(--brand)', letterSpacing: '-1px' }}>
            Marketer<span style={{ color: 'var(--text-1)' }}>Pro</span>
          </div>
          <p style={{ color: 'var(--text-3)', fontSize: 'var(--text-sm)', marginTop: 'var(--space-2)' }}>
            {mode === 'login' ? 'Welcome back' : mode === 'signup' ? 'Create your account' : 'Reset your password'}
          </p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
          {mode === 'signup' && (
            <div>
              <label htmlFor="auth-name" style={labelStyle}>Your Name</label>
              <input id="auth-name" type="text" placeholder="Jane Smith" value={name} onChange={e => setName(e.target.value)} autoComplete="name" />
            </div>
          )}
          <div>
            <label htmlFor="auth-email" style={labelStyle}>Email</label>
            <input id="auth-email" type="email" placeholder="you@yourbrand.com" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" aria-required="true" />
          </div>
          {mode !== 'forgot' && (
            <div>
              <label htmlFor="auth-password" style={labelStyle}>Password</label>
              <input id="auth-password" type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} aria-required="true" />
            </div>
          )}

          {message && (
            <p
              role="alert"
              aria-live="assertive"
              style={{
                padding: 'var(--space-3)',
                borderRadius: 'var(--radius-sm)',
                fontSize: 'var(--text-sm)',
                background: message.type === 'error' ? 'var(--danger-light)' : 'var(--accent-light)',
                color: message.type === 'error' ? 'var(--danger)' : 'var(--accent-dark)',
                userSelect: 'text',
              }}
            >
              {message.text}
            </p>
          )}

          <button
            onClick={handleSubmit}
            disabled={loading || !email || (mode !== 'forgot' && !password)}
            aria-busy={loading}
            style={{
              width: '100%',
              background: 'var(--brand)',
              color: 'white',
              border: 'none',
              borderRadius: 'var(--radius-md)',
              padding: 'var(--space-4)',
              fontFamily: 'var(--font-display)',
              fontWeight: 700,
              fontSize: 'var(--text-md)',
              cursor: loading ? 'wait' : 'pointer',
              minHeight: 56,
              opacity: loading ? 0.7 : 1,
              transition: 'opacity var(--duration-fast)',
            }}
          >
            {loading ? 'Please wait...' : mode === 'login' ? 'Sign In' : mode === 'signup' ? 'Create Account' : 'Send Reset Email'}
          </button>

          <div style={{ textAlign: 'center', fontSize: 'var(--text-sm)', color: 'var(--text-3)' }}>
            {mode === 'login' && (
              <>
                <button onClick={() => setMode('forgot')} style={{ background: 'none', border: 'none', color: 'var(--brand)', cursor: 'pointer', fontWeight: 500, minHeight: 'var(--touch-target)', padding: 'var(--space-2)' }}>
                  Forgot password?
                </button>
                <span style={{ margin: '0 var(--space-2)' }}>·</span>
                <button onClick={() => setMode('signup')} style={{ background: 'none', border: 'none', color: 'var(--brand)', cursor: 'pointer', fontWeight: 500, minHeight: 'var(--touch-target)', padding: 'var(--space-2)' }}>
                  Create account
                </button>
              </>
            )}
            {mode === 'signup' && (
              <button onClick={() => setMode('login')} style={{ background: 'none', border: 'none', color: 'var(--brand)', cursor: 'pointer', fontWeight: 500, minHeight: 'var(--touch-target)', padding: 'var(--space-2)' }}>
                Already have an account? Sign in
              </button>
            )}
            {mode === 'forgot' && (
              <button onClick={() => setMode('login')} style={{ background: 'none', border: 'none', color: 'var(--brand)', cursor: 'pointer', fontWeight: 500, minHeight: 'var(--touch-target)', padding: 'var(--space-2)' }}>
                Back to sign in
              </button>
            )}
          </div>
        </div>

        {/* Legal links — required by Apple and Google */}
        <div style={{ textAlign: 'center', marginTop: 'var(--space-8)', fontSize: 'var(--text-xs)', color: 'var(--text-3)' }}>
          By continuing, you agree to our{' '}
          <a href="https://marketer-pro.app/terms" style={{ color: 'var(--brand)', textDecoration: 'none' }}>Terms of Service</a>
          {' '}and{' '}
          <a href="https://marketer-pro.app/privacy" style={{ color: 'var(--brand)', textDecoration: 'none' }}>Privacy Policy</a>
        </div>
      </div>
    </div>
  )
}
